<?php require_once("../../lib/data_access_helper.php") ?>

<?php

	/*function addProductsToDb($products){
	$query="INSERT INTO productsdb(Type, Brand, Model, Price, Quantity, Details, Image) VALUES('$products['Type']','$products['Brand']','$products['Model']','$products['Price']','$products['Quantity']','$products['Details']','$products['Image']')";
		return executeNonQuery($query);
	}
	*/
	
	function addProductsToDb($brand,$id,$price,$quantity,$detail,$image){
	$query="INSERT INTO product(type, brand, id, price, quantity, details, image) VALUES('mobile','$brand','$id',50000,10,'$detail','$image')";
		return executeNonQuery($query);
	}
	
	function getProduct(){
		$query = "select * from product";  
		$result = executeQuery($query);
		//$row = mysqli_fetch_assoc($result);
		return $result;
	}
	
	function updateItem($brand,$id,$price,$quantity,$details){
		$query = "update product set details='$details',price='$price',quantity='$quantity',brand='$brand' where id='$id'";  
		$result = executeQuery($query);
		//$row = mysqli_fetch_assoc($result);
		return $result;
	}
	
	function deleteItem($id){
		$query = "DELETE FROM product WHERE id='$id'";  
		$result = executeQuery($query);
		//$row = mysqli_fetch_assoc($result);
		return $result;
	}
	
	function addItem($type,$brand,$id,$price,$quantity,$details,$image){
		$query = "insert into product values('$type','$brand','$id','$price','$quantity','$details','$image','')";  
		$result = executeQuery($query);
		//$row = mysqli_fetch_assoc($result);
		return $result;
	}
	
	function searchProductFromDb($search){
		$query = "SELECT * FROM product WHERE CONCAT(type, brand, id, price, quantity, details) LIKE '%{$search}%'";;
		$result = executeQuery($query);
		return $result;
	}
	
	function searchProductByTypeFromDb($search){
		$query = "SELECT * FROM product WHERE type='$search'";;
		$result = executeQuery($query);
		return $result;
	}
	function updateProductForCartDb($item_id){
		$query = "update product set quantity='$quantityTable' where id='$item_id'";
		$result = executeQuery($query);
		return $result;
	}
	
	function searchProductFromDbForcart($item_id){
		$query = "SELECT * FROM product WHERE id='$item_id'";
		$result = executeQuery($query);
		return $result;
	}

?>
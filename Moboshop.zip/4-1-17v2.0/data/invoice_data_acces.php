<?php require_once("../../lib/data_access_helper.php") ?>
<?php
	function invoiceTableToDb($userName, $userEmail, $cartTotal){
		$x=date("Y/m/d");
		$query="INSERT INTO invoice(id,customerName,customerEmail,date,totalPrice) VALUES('', '$userName', '$userEmail' ,'$x', $cartTotal)";
		return executeNonQuery($query);
	}
	function getEnvoice(){
		$query = "select * from invoice";  
		$result = executeQuery($query);
		//$row = mysqli_fetch_assoc($result);
		return $result;
	}
?>
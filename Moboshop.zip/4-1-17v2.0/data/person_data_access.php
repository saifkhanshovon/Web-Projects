﻿<?php require_once("../../lib/data_access_helper.php") ?>
<?php
	function addPersonToDb($person){
		$query = "INSERT INTO persondb(Name,Email,Password,Phone,Type,Address) VALUES('$person[name]', '$person[email]', '$person[password]' ,'$person[phonenumber]', 'user', '$person[address]')";
		return executeNonQuery($query);
	}	
	
	function getAllPassword($email,$password){
		$query = "SELECT * FROM persondb where Email='".$email."'";  
		$result = executeQuery($query);
		$row = mysqli_fetch_assoc($result);
		$pass= $row['Password'];
		$type= $row['Type'];
		$name= $row['Name'];
		$email= $row['Email'];
		$address= $row['Address'];
		$phone= $row['Phone'];
		$arr = array("password"=>$pass,"type"=>$type,"name"=>$name,"email"=>$email,"address"=>$address,"phone"=>$phone);
		return $arr;
	}
	
	function accountSettingsToDb($person){
		$query="UPDATE persondb SET Name= '$person[name]',Password= '$person[password]',Phone= '$person[phonenumber]',Type= 'user',Address= '$person[address]' WHERE Email= '$person[email]'";
		$result = executeQuery($query);
		return $result;
	}
	
	function getPersonFromDb($email){
		$query="SELECT * FROM persondb WHERE Email='$email'";
		$result = executeQuery($query);
		return $result;
	}
	
?>
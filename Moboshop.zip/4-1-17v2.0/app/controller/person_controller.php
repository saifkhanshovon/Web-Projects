<?php 
	if(!isset($isDispatchedByFrontController)){
		include_once("../error.php");
		die;
	}
?>
<?php include_once(APP_ROOT."/core/person_service.php"); ?>
<?php
	switch($view){
		case "add":
			include_once(APP_ROOT."/app/view/person_add_view.php");
			break;
			
		case "edit":
			if(isset($_GET['id'])){
				$id = $_GET['id'];
				$person = getPersonById($id); //Getting the model for view
				if($person){
					include_once(APP_ROOT."/app/view/person_edit_view.php");					
				}
			}
			break;
			
		case "delete":
			if(isset($_GET['id'])){
				$id = $_GET['id'];
				$person = getPersonById($id); //Getting the model for view
				if($person){
					include_once(APP_ROOT."/app/view/person_delete_view.php");
				}
			}
			break;
			
		case "show":
			$personList = getAllPerson(); //Getting the model for view
			if(count($personList)>0){
				include_once(APP_ROOT."/app/view/person_show_view.php");
			}
			break;
			
		default:
			include_once(APP_ROOT."/app/error.php");
	}	
?>
<?php $p="../../images/"; ?>
<html>
	
	<style>

		body{
			//background-image:url("../../images/home.jpg");
		}
		
		.container{
			width: 300px;
			height: 500px;
			background-color: #000;
			margin: 0px auto;
			text-align: center;
			border-radius: 5px;
			opacity: .7;
		}
		.container img{
			width: 100px;
			height: 100px;
			border-radius: 500px;
			background: $fff;
			padding: 5px;
			margin-top: -60px;
			margin-bottom: 30px;
		}
		input[type="text"],[type="password"]{
			width: 250px;
			height: 45px;
			font-size: 17px;
			margin-bottom: 20px;
			padding-left: 30px;
			background: #fff;
			border: none;
		}
		
		.signup{
			border: none;
			padding: 15px 30px;
			background: #2ECC71;
			border-radius: 5px;
			cursor: pointer;
			border-bottom: 5px solid #27AE60;
		}
		
		.home{
			width: 50px:
			border: none;
			padding: 15px 30px;
			background: #2ECC71;
			//background-image: url("../../images/bmw.jpg");
			border-radius: 5px;
			cursor: pointer;
			border-bottom: 5px solid #27AE60;
		}	
		.menu{
			background-color: cyan;
			padding: 10px;
		}
		
	</style>
	<form method="post" name="signupForm" onsubmit="return validateForm()" >
		<body>
			<table  width=100%>
			
				<tr>
						<td align="center">
							<!--<img src="../../images/logo.PNG"  height=180 width=60% id="image"> <hr/>-->
							<img src="../../images/logo.PNG"  height=120 width=60% id="image"> <hr/>
						</td>
				</tr>

				<table class="menu" width=100%>
							<tr>
								<td>
									<button name="home" class="home" onclick="window.location.href='home.php';">
										Home
									</button>
								</td>
							</tr>
				</table>
				<br/><br/><br/>
				<div class="container">
					<img src="../../images/login.png" alt="founder">
							
						<div>
							<tr>
								<td align="center">
									<input type="text"  id="username" name="username" placeholder="Enter Your Name"></input>
								</td>
							</tr>
						</div>
						<div>
							<tr>
								<td align="center">
									<input type="password" id="password" name="password" placeholder="Enter Your Password"></input>
								</td>
							</tr>
						</div>
						<div>
							<tr>
								<td align="center">
									<input type="password" id="retypepassword" name="retypepassword" placeholder="Re Type Password"></input>
								</td>
							</tr>
						</div>
						<div>
							<tr>
								<td align="center">
									<input type="text"  id="phonenumber" name="phonenumber" placeholder="Contact Number (+880)"></input>
								</td>
							</tr>
						</div>
						<div>
							<tr>
								<td align="center">
									<input type="text"  id="email" name="email" placeholder="Email"></input>
								</td>
							</tr>
						</div>
						<div>
						<div>
							<tr>
								<td align="center">
									<input type="text"  id="address" name="address" placeholder="Address"></input>
								</td>
							</tr>
						</div>
						<div>
							<tr>
								<td align="center">
									<input type="submit" value="SIGN UP" name="submit" class="signup"/>
								</td>
							</tr>
						</div>
						

				
			</table>
		</body>
		<span id="nameErr"></span>
	</form>
</html>
<?php include_once("../../core/person_service.php"); ?>
<?php

	if($_SERVER['REQUEST_METHOD']=="POST"){
		if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['retypepassword']) && isset($_POST['phonenumber']) && isset($_POST['email']) && isset($_POST['address'])){
			
		$name=$_POST['username'];
		$password=$_POST['password'];
		$retypepassword=$_POST['retypepassword'];
		$phonenumber=$_POST['phonenumber'];
		$email=$_POST['email'];
		$address=$_POST['address'];
		
		
			
		
		$person= array("name"=>$name,"password"=>$password,"phonenumber"=>$phonenumber,"email"=>$email,"address"=>$address);
		addUser($person);
		}
	}
	
?>


<script>
	
	function validateForm(){
		var email = document.forms["signupForm"]["email"].value;
		var password = document.forms["signupForm"]["password"].value;
		var retypepassword = document.forms["signupForm"]["retypepassword"].value;
		var name = document.forms["signupForm"]["username"].value;
		var phonenumber = document.forms["signupForm"]["phonenumber"].value;
		var address = document.forms["signupForm"]["address"].value;
		var atpos = email.indexOf("@");
		var dotpos = email.lastIndexOf(".");
		
		if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length) {
			alert("Invalid Input!!!");
			return false;
		}
		else if(password.length<5 || password!= retypepassword){
			alert("Invalid Input!!!");
			return false;
		}
		
		else if(1) {
			var validChar='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
			if(((name >='a' && name<='z')||(name >='A' && name<='Z') && ((name=='.- ') || (name >='a' && name<='z')||(name >='A' && name<='Z') ) ) )
				return true;
			
			alert("Invalid Input name!!!");
			return false;
		}
		else if(phonenumber.length!=10){
			alert("Invalid Input!!!");
			return false;
		}
		
		else if(address==""){
			alert("Invalid Input!!!");
			return false;
		}
		
		return true;
		
	}

</script>

<html>
	<style>
		.home{
			width: 50px:
			//border: none;
			padding: 5px 10px;
			background: #2ECC71;
			border-radius: 9px;
			cursor: pointer;
			color: white;
			font-size: 20px;
			border-bottom: 5px solid #27AE60;
		}
	</style>

<table  width=100%>
		
			<tr>
				<td align="center">
					<img src="../../images/logo.PNG"  height=130 width=60% id="image"> <hr/>
				</td>
			</tr>
			
			<table class="menu" align="center">
				<tr>
					<td>
						<button name="home" id="home" class="home" onclick="window.location.href='home.php';">
							Home
						</button>
					</td>
			</table>
			
			<br/><br/><br/><br/><br/>
			
			<div>
				<h1>THIS PROJECT IS DONE BY</h1>
				<h2>Hanif,Md.Abu</h2>
				<h2>Shovon,Md.Saife Khan</h2>
				<h2>Susmoy,Md.Sabiqul Haque</h2>
			</div>
</table>
</html>
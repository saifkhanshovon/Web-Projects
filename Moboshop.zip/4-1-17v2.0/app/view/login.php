<?php $p="../../images/"; ?>

<html>

	<style>
		body{
			background-image:url("../../images/home.jpg");
		}
		
		.container{
			width: 300px;
			height: 300px;
			background-color: #000;
			margin: 0px auto;
			text-align: center;
			border-radius: 5px;
			opacity: .7;
		}
		.container img{
			width: 100px;
			height: 100px;
			border-radius: 500px;
			background: $fff;
			padding: 5px;
			margin-top: -60px;
			margin-bottom: 30px;
		}
		input[type="text"],[type="password"]{
			width: 250px;
			height: 45px;
			font-size: 17px;
			margin-bottom: 20px;
			padding-left: 30px;
			background: #fff;
			border: none;
		}
		
		.login{
			border: none;
			padding: 15px 30px;
			background: #2ECC71;
			border-radius: 5px;
			cursor: pointer;
			border-bottom: 5px solid #27AE60;
		}
		
		.home{
			width: 50px:
			border: none;
			padding: 15px 30px;
			background: #2ECC71;
			border-radius: 5px;
			cursor: pointer;
			border-bottom: 5px solid #27AE60;
		}
		.signup{
			width: 50px:
			border: none;
			padding: 15px 30px;
			background: #2ECC71;
			border-radius: 5px;
			cursor: pointer;
			border-bottom: 5px solid #27AE60;
		}
		
		.menu{
			background-color: cadetblue;
			padding: 10px;
		}
		
	</style>
	<body>
		<form method="post" name="loginForm"  onsubmit="return validateForm()">
			
			
			<table  width=100%>
				
					<tr>
						<td align="center">
							<!--<img src="../../images/logo.PNG"  height=180 width=60% id="image"> <hr/>-->
							<img src="../../images/logo.PNG"  height=120 width=60% id="image"> <hr/>
						</td>
					</tr>

					<table class="menu">
						<tr>
							<td>
								<button name="home" class="home" onclick="window.location.href='home.php';">
									Home
								</button>
							</td>
							<td width=80%>
							</td>
							<td>
								<!--Need an Account ? <a href="signup.html">Signup</a>-->
								Need an Account ? 
								<button name="signup" class="signup" onclick="window.location.href='signup.php';">
									SIGNUP
								</button>
							</td>
						</tr>
					</table>
					
					<br/><br/><br/>
					<div class="container">
						<table width=100% align="center" >
							<img src="../../images/login.png" alt="founder">
							
							<div>
								<tr>
									<td align="center">
											<input type="text"  id="email" name="email" placeholder="Enter Your Email"></input>
									</td>
								</tr>
							</div>
							<div>
								<tr>
									<td align="center">
											<input type="password" id="password" name="password" placeholder="Enter Your Password"></input>
									</td>
								</tr>
							</div>
							
							<tr>
									<td align="center">
											<input type="submit" value="LOGIN" name="submit" class="login"/>
									</td>
							</tr>
							
						</table>
					</div>
					<hr/>
					
				</table>
				<span id="nameErr"></span>
		</form>
	</body>
</html>


<?php include_once('../../core/person_service.php'); ?>
<?php
	var_dump($_COOKIE['user']);
			if(isset($_COOKIE['user'])){
				if($_SESSION['user']=="ADMIN"){
					var_dump($_COOKIE['user']);
					session_start();
					header("location: home.php");
				}
				
				else{
					session_start();
					header("location: home.php");
				}
			}
		
		else if($_SERVER['REQUEST_METHOD']=="POST"){
			if(isset($_POST['email']) && isset($_POST['password'])){
			$email = $_POST['email'];
			$password = $_POST['password'];
		
		$person = array("email"=>$email , "password"=>$password);
		$getPersonData = login($person);
		
		if($getPersonData["type"]=="ADMIN"){
		
			session_start();
			$_SESSION["user"]=$getPersonData["type"];
			setcookie("user", $getPersonData["email"]);
			header("location: home.php");
			
		}
		else if($getPersonData["type"]=="user"){
				session_start();
				$_SESSION["user"]=$getPersonData["type"];
				setcookie("user", $getPersonData["email"]);
				header("location: home.php");
				}
		
			}
		}

?>

<script>
	
	function validateForm(){
		var email = document.forms["loginForm"]["email"].value;
		var password = document.forms["loginForm"]["password"].value;
		var atpos = email.indexOf("@");
		var dotpos = email.lastIndexOf(".");
		
		if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length) {
			alert("Invalid E-mail or Password!!!");
			return false;
		}
		else if(password.length<5){
			alert("Invalid E-mail or Password!!!");
			return false;
		}
		return true;
		
	}
	
</script>
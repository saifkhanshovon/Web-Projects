<?php 

	session_start();
	if(!isset($_COOKIE['user'])){
		header("location:home.php");
		
	}

	if(isset($_COOKIE['user'])){
		if($_SESSION['user']=="user"){
			header("location:home.php");
		}
		
	}
	
?>


<html>
	<style>
	body{
			//background-color: CadetBlue;
		}
		table{
			border-collapse: collapse;
			text-align: center;
			
		}
		
		table th{
			text-align: left;
			background-color: #3a6070;
			color: #FFF;
			padding: 4px 30px 4px 8px;
		}
		
		table td{
			border: 1px solid #e3e3e3;
			padding: 4px 8px
		}
		
		table tr:nth-child(even) td{
			background-color: #e7edf0;
			

		}
		
		.addToCart {
			border-radius: 12px;
			background-color: Gold;
			color: #FFFFFF;
			font-size: 20px;
			
		}
		

		.home {
			font-size: 25px;
			border-radius: 5px;
			background-color: SteelBlue;
			color: #FFFFFF;
			
		}
		
		.title{
			//border-style:double red;
			border: 2px solid;
			border-radius: 8px;
			outline-style: double;
			outline-color: green;
			outline-width: thick;
			//padding-right: 30px;
			margin-right: 5%;
			margin-left: 5%;

		}
	</style>

<body>
	<table width=100%>
		<tr>
				<td align="center">
					<img src="../../images/logo.PNG"  height=130 width=60% id="image"> <hr/>
				</td>
			</tr>
	</table>
	<br/>
	
	<table width=90% align="center" style="background-color: SteelBlue ;">
		<tr>
			<td align="left" >
						
						<a href="home.php"><button type="button" class="button home" style="background-color: #F08080;">Home</button></a>
			</td>
			<td align="right" >
						
						<a href="index.php"><button type="button" class="button home" style="background-color: #4CAF50;">Product</button></a>
			</td>
		</tr>
	</table>
	<br/>
	
	</br>
	
	<table width=85% align="center">	
		<tr >
				<th>Order Id</th>
				<th>Client Name</th>
				<th>Client Email</th>
				<th>Sell Date</th>
				<th>Total Bill</th>

		</tr>
		
<?php include_once("../../core/invoice.php"); ?>

<?php
	
	$res= getAllEnvoice();			
	
	while($row=mysqli_fetch_assoc($res)){
	
		echo "<tr>";
		echo "<td>"; echo $row["id"]; echo "</td>";
		echo "<td>"; ?><div id="name<?php echo $row["id"]; ?>"><?php echo $row["customerName"]; ?></div> <?php echo "</td>";
		echo "<td>"; ?><div id="email<?php echo $row["id"]; ?>"><?php echo $row["customerEmail"]; ?></div> <?php echo "</td>";
		echo "<td>"; ?><div id="date<?php echo $row["id"]; ?>"><?php echo $row["date"]; ?></div> <?php echo "</td>";
		echo "<td>"; ?><div id="total<?php echo $row["id"]; ?>"><?php echo $row["totalPrice"]; ?></div> <?php echo "</td>";	?>			

<?php		
	
	echo "</tr>";

	}
	echo "</table>";
	
	
	
?>

</body>
</html>
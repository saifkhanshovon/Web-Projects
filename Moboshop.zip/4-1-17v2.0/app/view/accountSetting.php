<?php $p="../../images/"; ?>
<html>
	
	<style>

		body{
			//background-image:url("../../images/home.jpg");
		}
		
		.container{
			width: 300px;
			height: 430px;
			background-color: #000;
			margin: 0px auto;
			text-align: center;
			border-radius: 5px;
			opacity: .7;
		}
		.container img{
			width: 100px;
			height: 100px;
			border-radius: 500px;
			background: $fff;
			padding: 5px;
			margin-top: -60px;
			margin-bottom: 30px;
		}
		input[type="text"],[type="password"]{
			width: 250px;
			height: 45px;
			font-size: 17px;
			margin-bottom: 20px;
			padding-left: 30px;
			background: #fff;
			border: none;
		}
		
		.save{
			border: none;
			padding: 15px 30px;
			background: #2ECC71;
			border-radius: 5px;
			cursor: pointer;
			border-bottom: 5px solid #27AE60;
		}
		
		.home{
			width: 50px:
			//border: none;
			padding: 5px 10px;
			background: #2ECC71;
			border-radius: 9px;
			cursor: pointer;
			color: white;
			font-size: 20px;
			border-bottom: 5px solid #27AE60;
		}
		.logout{
			width: 50px:
			border: none;
			padding: 5px 10px;
			background: #2ECC71;
			border-radius: 9px;
			cursor: pointer;
			color: red;
			font-size: 20px;
			border-bottom: 5px solid #27AE60;
		}		
		.menu{
			background-color: cadetblue;
			padding: 10px;
		}
		
	</style>
	<form method="post" id="form2" onsubmit="return show()" >
		<body>

				<table  width=100%>
				
					<tr>
						<td align="center">
							<!--<img src="../../images/logo.PNG"  height=180 width=60% id="image"> <hr/>-->
							<img src="../../images/logo.PNG"  height=120 width=60% id="image"> <hr/>
						</td>
					</tr>
					
					
					<table class="menu">
						<tr>
							<td>
								<input type="button" name="home" class="home" value="Home" onclick="window.location.href='home.php';"/>
							</td>
							<td align="center" width=100% style="color:white; font-size: 30px;">
								<p> Account Settings </p>
							</td>
							<td>
								<input name="logout" class="logout" value="Logout" onclick="window.location.href='logout.php';">
									
								</input>
							</td>
						</tr>
					</table>
				<br/><br/><br/>
				<div class="container">
					<img src="../../images/login.png" alt="founder">
							
						<div>
							<tr>
								<td align="center">
									<input type="text"  id="username" name="username" placeholder="Enter Your Name"></input>
								</td>
							</tr>
						</div>
						<div>
							<tr>
								<td align="center">
									<input type="password" id="password" name="password" placeholder="Enter Your Password"></input>
								</td>
							</tr>
						</div>
						<div>
							<tr>
								<td align="center">
									<input type="password" id="retypepassword" name="retypepassword" placeholder="Re Type Password"></input>
								</td>
							</tr>
						</div>
						<div>
							<tr>
								<td align="center">
									<input type="text"  id="phonenumber" name="phonenumber" placeholder="Contact Number (+880)"></input>
								</td>
							</tr>
						</div>
						<div>
						<div>
							<tr>
								<td align="center">
									<input type="text"  id="address" name="address" placeholder="Address"></input>
								</td>
							</tr>
						</div>
						<div>
							<tr>
								<td align="center">
									<input type="submit" value="SAVE" name="submit" class="save"/>
								</td>
							</tr>
						</div>
						<br/><br/>

			</table>
		</body>
		<span id="nameErr"></span>
	</form>
</html>
<?php $x='' ?>
<?php include_once("../../core/person_service.php"); ?>
<?php
	if(isset($_COOKIE['user'])){
		if($_SERVER['REQUEST_METHOD']=="POST"){
		if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['retypepassword']) && isset($_POST['phonenumber']) && isset($_POST['address'])){
			
		$name=$_POST['username'];
		$password=$_POST['password'];
		$retypepassword=$_POST['retypepassword'];
		$phonenumber=$_POST['phonenumber'];
		//$email=$_POST['email'];
		$address=$_POST['address'];

	if(!empty($name)&&!empty($password)&&!empty($retypepassword)&&!empty($phonenumber)&&!empty($address)){
	$person= array("name"=>$name,"password"=>$password,"phonenumber"=>$phonenumber,"email"=>$_COOKIE['user'],"address"=>$address);
	accountSettings($person);
	
	}
	}
	}
}	
	
?>



<script>
	
	function show(){
		var userName = document.getElementById("name");
		var password = document.getElementById("password");
		//document.write(userName.value);
		
		if(userName.value == ""){
			//alert("Name can not be empty");
			var nameErr = document.getElementById("nameErr");
			nameErr.innerHTML = "Name can not be empty";
			return false;
		}
		
	/*	var passValue=password.value;
		
		if(passValue.length()<5){
			document.write("Password Error!!");
			return false;
		}
		*/	
		alert("account Updated successfully !!");
		return true;
	}

</script>

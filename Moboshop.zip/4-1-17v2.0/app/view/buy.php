<html>
	<body>
		<table  width=100%>
		
			<tr>
				<td align="center">
					<h1>Mobo Shop.Com</h1>
				</td>
			</tr>
			
			<table>
				<tr>
					<td>
						<button name=home>
							Home
						</button>
					</td>
				</tr>
			</table>
			
			<table border=1 width=100%>
				<tr>
					<td>
						<h3>
                            Customer Name
                            <input type="text" name="customername"></input>
                        </h3>
					</td>
                </tr>
                <tr>
                    <td>
                        <h3>
                            Email Address
                            <input type="text" name="email"></input>
                        </h3>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h3>
                            Contact Number
                            <input type="text" name="contactno"></input>
                        </h3>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h2>
                            Total Bill
                            <input type="text" name="total"></input>
                        </h2>
                    </td>
                </tr>
                <tr>
                    <td align="right">
                        <button name="buy">
                            <h2>Buy Product</h2>
                        </button>
                    </td>
                </tr>
			</table>
			
		</table>
	</body>
</html>

<?php $p="../../images/"; ?>
<?php 
session_start();
$x="Guest";
$indexValue="productUser.php";
	if(isset($_COOKIE['user']) && isset($_SESSION['user'])){
		$x=$_COOKIE['user'];
		$val=$_SESSION['user'];
		if($val=="ADMIN"){
			$indexValue="index.php";
		}
		else{
			$indexValue="productUser.php";
		}
	}
?>

<html>

	<style>
		.menu{
			background-color: Cadetblue;
			width: 100%;
			height: 5px;
		}
		
		/*.home{
			font-size: 25px;
			background-color: orangered;
			border-radius: 5px;
			color: #FFFFFF; 
		}*/
		
		.home{
			width: 50px:
			//border: none;
			padding: 5px 10px;
			background: #2ECC71;
			border-radius: 9px;
			cursor: pointer;
			color: white;
			font-size: 20px;
			border-bottom: 5px solid #27AE60;
		}
		.products{
			width: 50px:
			//border: none;
			padding: 5px 10px;
			background: #2ECC71;
			border-radius: 9px;
			cursor: pointer;
			color: white;
			font-size: 20px;
			border-bottom: 5px solid #27AE60;
		}
		

		.dropdown{
			position: relative;
			display: inline-block;
		}
		.dropdown-content{
				display: none;
				position: absolute;
				background-color: #f9f9f9;
				min-width: 115px;
				box-shadow: 0px 8px 16px 0px rgba(0,0,0,1);
		}
		.dropdown-content a{
			color: black;
			text-decoration: none;
			display:block;
		}
		.dropdown:hover .dropdown-content{
			display: block;
		}
		.dropdown:hover .products{
			background-color: #3e8e41;
		}
		
		.about{
			width: 50px:
			//border: none;
			padding: 5px 10px;
			background: #2ECC71;
			border-radius: 9px;
			cursor: pointer;
			color: white;
			font-size: 20px;
			border-bottom: 5px solid #27AE60;
		}
		.search{
			font-size: 25px;
			background-color: gold;
			border-radius: 5px;
			color: white;
			cursor: pointer;
		}
		
		.search_value{
			width: 600px;
			font-size: 25px;
			border-radius: 5px;
			color: black;
			cursor: pointer;
		}
		.login{
			width: 50px:
			//border: none;
			padding: 5px 10px;
			background: #2ECC71;
			border-radius: 9px;
			cursor: pointer;
			color: white;
			font-size: 20px;
			border-bottom: 5px solid #27AE60;
		}
		.myaccount{
			width: 50px:
			//border: none;
			padding: 5px 10px;
			background: #2ECC71;
			border-radius: 9px;
			cursor: pointer;
			color: white;
			font-size: 20px;
			border-bottom: 5px solid #27AE60;
		}
		
		.previous{
			width: 50px:
			border: none;
			padding: 15px 30px;
			background: #2ECC71;
			border-radius: 5px;
			cursor: pointer;
			border-bottom: 5px solid #27AE60;
		}
		
		.next{
			width: 50px:
			border: none;
			padding: 15px 30px;
			background: #2ECC71;
			border-radius: 5px;
			cursor: pointer;
			border-bottom: 5px solid #27AE60;
		}
		
		
		
	</style>

	<body>
		<table  width=100%>
		
			<tr>
				<td align="center">
					<img src="../../images/logo.PNG"  height=130 width=60% id="image"> <hr/>
				</td>
			</tr>
			<table class="menu" align="center">
				<tr>
					<td>
						<button name="home" id="home" class="home" onclick="window.location.href='home.php';">
							Home
						</button>
					</td>
					<td>
						<div class="dropdown">
							<button name="products" id="products" class="products" onclick="window.location.href='<?php echo"$indexValue"?>?value=all product';">
								Products
							</button>
							<div class="dropdown-content">
								<a href='<?php echo"$indexValue"?>?value=Mobile'>Mobile</a>
								<a href='<?php echo"$indexValue"?>?value=Laptop'>Laptop</a>
								<a href='<?php echo"$indexValue"?>?value=Tablet'>Tablet</a>
							</div>
						</div>
					</td>
					<td>
						<button name="about" id="about" class= "about" onclick="window.location.href='about.php';">
							About
						</button>
					</td>
					<td>
						<form   method="POST" action="<?php echo"$indexValue"?>">
								<input type="text" name="valueToSearch" class="search_value" placeholder=" Search Your Product"/>
								<input type="submit" name="search" class="search" value="search" onclick="searchProduct()">
								
								<!--<a href='index.php?postid=""'>edit</a>-->
						</form>
                    </td>
					
                    <td style="color:white;">
                       <P><?php echo "WELCOME: $x" ?> </p> 
                    </td>
					
					
					<td>
						<button name="myaccount" id="myaccount" class="myaccount" onclick="window.location.href='accountsetting.php';">
							My Account
						</button>
					</td>
					<td>
						<button name="login" id="login" class="login" onclick="window.location.href='login.php';">
							Login
						</button>
					</td>

				</tr>
			</table>
			<h2 align="center" style="font-size:30px; font-variant: small-caps; font-style: oblique; color: red;">New Arrival ! </h2>
			
			<table border="1" width="100%">
                <tr>
					
					<?php
						$link=mysqli_connect("localhost","root","");
						mysqli_select_db($link,"moboshop");
						$sql=mysqli_query($link,"SELECT * FROM product ORDER BY serialkey DESC LIMIT 5");
						while ($row = mysqli_fetch_assoc($sql)) {
						$pic = $row['image'];
						$p="../../images/";
						$id = $row['id'];
					?>
						<td align="center">
					<?php echo "<img src='".$p.$pic."'  height=150 width=150>"; ?>
				
							<form   method="POST" action="<?php echo"$indexValue"?>">
								<input type="text" name="valueToSearch" value="<?php echo "$id"; ?>" style="display: none;"/>
								<p><?php echo "$id"; ?></p>
								<input type="submit" name="search" value="view Product" class="home">			
							</form>			
<?php			
			echo "</td>";				
		}
		

			
			
?>

                </tr>
            </table>
			
			<br/><hr/><br/>
			<table width=100% style="background:cadetblue; height:90px;">
				<tr>
					<td align="center">
						<img src="../../images/iphonelogo.jpg"  height=50 width=100 id="image">						
					</td>
					<td align="center">
						<img src="../../images/samsunglogo.jpg"  height=50 width=100 id="image">						
					</td>
					<td align="center">
						<img src="../../images/milogo.png"  height=50 width=100 id="image">						
					</td>
					<td align="center">
						<img src="../../images/htclogo.png"  height=50 width=100 id="image">						
					</td>
					<td align="center">
						<img src="../../images/motologo.png"  height=50 width=100 id="image">						
					</td>
					
				</tr>
			</table>  
           <hr/> 
		</table>
	
	</body>
</html>

<!--
<div id="disp_data"></div>
<script type="text/javascript">
var count=1;
	function next(){
		var image = document.getElementById("image");
		count=count+1;
		image.src = "../../images/"+count+".jpg";
		if(count==3)
			count=0;
	}
	function prev(){
		var image = document.getElementById("image");
		count = count-1;
		
		if(count==0)
			count=3;
		image.src = "../../images/"+count+".jpg";
	}
	
	/*function searchProduct(){
	//alert("asdafdsafd");
	
		var sproduct = document.getElementById('search_value').value;
		
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.open("GET","productAdmin.php?data="+sproduct+"&status=s",false);
		xmlhttp.send(null);
		alert(xmlhttp.responseText);
		//document.getElementById("disp_data").innerHTML=xmlhttp.responseText;
	
	}
	*/
	
	function searchProduct(){
		var sproduct = document.getElementById('search_value').value;
		//alert("Product Added to Cart");
		$.post('productAdmin.php',{value:sproduct},
		function(){
			$('#result').html(data);
		} );
	}
</script>

<script type="text/javascript">

	
	function searchProduct(){
		var sproduct = document.getElementById('search_value').value;
		//alert("Product Added to Cart");
		$.post('productAdmin.php',{value:sproduct},
		function(){
			$('#result').html(data);
		} );
	}
</script>
-->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js">
function foo () {
      $.ajax({
        url:"cart.php", //the page containing php script
        type: "POST", //request type
        success:function(result){
         alert(result);
       }
     });
 }

</script>

<html>
	<body>
	</body>
</html>

<html>
	<style>
	
		body{
			//background-color: CadetBlue;
		}
		table{
			border-collapse: collapse;
			text-align: center;
			
		}
		
		table th{
			text-align: left;
			background-color: #3a6070;
			color: #FFF;
			padding: 4px 30px 4px 8px;
		}
		
		table td{
			border: 1px solid #e3e3e3;
			padding: 4px 8px
		}
		
		table tr:nth-child(even) td{
			background-color: #e7edf0;
			

		}
		
		.addToCart {
			border-radius: 12px;
			background-color: Gold;
			color: #FFFFFF;
			font-size: 20px;
			
		}
		

		.home {
			font-size: 25px;
			border-radius: 5px;
			background-color: SteelBlue;
			color: #FFFFFF;
			
		}
		.cart {
			font-size: 25px;
			border-radius: 5px;
			background-color: Gold;
			color: #FFFFFF;
			
		}
		
		.title{
			//border-style:double red;
			border: 2px solid;
			border-radius: 8px;
			outline-style: double;
			outline-color: green;
			outline-width: thick;
			//padding-right: 30px;
			margin-right: 5%;
			margin-left: 5%;

		}
		
	</style>
	<script type="text/javascript" src="jquery.js"></script>

<body>
	
	<table width=100%>
		<tr>
				<td align="center">
					<img src="../../images/logo.PNG"  height=130 width=60% id="image"> <hr/>
				</td>
			</tr>
	</table>
	
	<table width=90% align="center" style="background-color: SteelBlue ;">
		
		<tr>
			<td align="left" >
						
						<a href="home.php"><button type="button" class="button home" style="background-color: #F08080;">Home</button></a>
			</td>
			<td align="right" >
						
						<a href="cartIndex.php"><button type="button" class="button home" style="background-color: #4CAF50;">My Cart</button></a>
			</td>
		</tr>
	</table>
	<br/>
	
	</br>
	
	<table width=85% align="center">	
		<tr >
				<th>Image</th>
				<th>Model</th>
				<th>Detail</th>
				<th>Brand</th>
				<th>Price</th>
				<th>Stock</th>
				<th>Add to Cart</th>
			</tr>



<?php include_once("../../core/productService.php"); ?>

<?php
	//var_dump($_GET['value']);
	if ( ! empty($_POST['valueToSearch'])){
		$searchValue = $_POST['valueToSearch'];
		$res = searchProduct($searchValue);
		displayData($res);
	}
	else if(isset($_GET['value'])){
		$searchValue=$_GET['value'];
		if($searchValue=="all product"){
			$res= getAllProducts();			
			displayData($res);
		}
		else{
			$res = searchProductByType($searchValue);
			displayData($res);
		}
		
	}
	else{
		header("location:home.php");
	}

	function displayData($res){
		while($row=mysqli_fetch_assoc($res)){

		$pic = $row['image'];
		$p="../../images/";
	
		echo "<tr>";
		echo "<td>"; echo "<img src='".$p.$pic."'  height=100 width=100>"; echo "</td>";
		echo "<td>"; echo $row["id"]; echo "</td>";
		echo "<td>"; ?><div id="details<?php echo $row["id"]; ?>"><?php echo $row["details"]; ?></div> <?php echo "</td>";
		echo "<td>"; ?><div id="brand<?php echo $row["id"]; ?>"><?php echo $row["brand"]; ?></div> <?php echo "</td>";
		echo "<td>"; ?><div id="price<?php echo $row["id"]; ?>"><?php echo $row["price"]; ?></div> <?php echo "</td>";
		echo "<td>"; ?><div id="quantity<?php echo $row["id"]; ?>"><?php echo $row["quantity"]; ?></div> <?php echo "</td>";
		
		
		/*echo "<td>"; ?><form id="cartForm" name="cartForm" method="post" action="cart.php">
		<input type="hidden" name="pid" id="pid" value="<?php echo $row["id"]; ?>"/>
		<input type="submit" name="cartButton" value="Add to Cart"/>
		</form>*/
		
		echo "<td>"; ?> <input type="button" id="<?php echo $row["id"]; ?>" name="<?php echo $row["id"]; ?>" value="Add To Cart" class="button addToCart" onclick="post(this.id)"> <?php echo "</td>";

	}
	}
	
	
	?>

<?php		
	
	echo "</tr>";


	echo "</table>";
	
	
	
?>

<script type="text/javascript">
	function post(id){
		
		var price="price"
		var priceId = price+id;
		var p=document.getElementById(priceId).innerHTML;

		alert("Product Added to Cart");
		$.post('cart.php',{postid:id,postprice:p},
		function(){
			$('#result').html(data);
		} );
	}
</script>



</body>
</html>














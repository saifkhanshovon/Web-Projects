<html>
	<body>
	</body>
</html>

<html>
	<style>
	
		body{
			//background-color: CadetBlue;
		}
		table{
			border-collapse: collapse;
			text-align: center;
			
		}
		
		table th{
			text-align: left;
			background-color: #3a6070;
			color: #FFF;
			padding: 4px 30px 4px 8px;
		}
		
		table td{
			border: 1px solid #e3e3e3;
			padding: 4px 8px
		}
		
		table tr:nth-child(even) td{
			background-color: #e7edf0;
			

		}
		
		.delet {
			border-radius: 12px;
			background-color: #f4511e;
			color: #FFFFFF;
			font-size: 20px;
			
		}
		
		.button2 {
			border-radius: 12px;
			background-color: SteelBlue;
			color: #FFFFFF;
			font-size: 20px
			
			
		}
		
		.button3 {
			border-radius: 12px;
			background-color: #4CAF50;
			color: #FFFFFF;
			font-size: 20px;
			
		}
		.add {
			font-size: 25px;
			border-radius: 5px;
			background-color: #4CAF50;
			color: #FFFFFF;
			
		}
		
		.home {
			font-size: 25px;
			border-radius: 5px;
			background-color: SteelBlue;
			color: #FFFFFF;
			
		}
		.cart {
			font-size: 25px;
			border-radius: 5px;
			background-color: Gold;
			color: #FFFFFF;
			
		}
		
	</style>
	

<body>
	
	</br>
	
	<table width=85% align="center">	
		<tr >
				<th>Image</th>
				<th>Model</th>
				<th>Detail</th>
				<th>Brand</th>
				<th>Price</th>
				<th>Stock</th>
				<th>Delete</th>
				<th>Edit</th>
			</tr>

</body>
</html>

<?php include_once("../../core/productService.php"); ?>

<?php
	
	$status=$_GET["status"];
	

	if($status=="disp")
	{
		
			$res= getAllProducts();			
		
		while($row=mysqli_fetch_assoc($res)){

			$pic = $row['image'];
			$p="../../images/";
		
			echo "<tr>";
			echo "<td>"; echo "<img src='".$p.$pic."'  height=100 width=100>"; echo "</td>";
			echo "<td>"; echo $row["id"]; echo "</td>";
			echo "<td>"; ?><div id="details<?php echo $row["id"]; ?>"><?php echo $row["details"]; ?></div> <?php echo "</td>";
			echo "<td>"; ?><div id="brand<?php echo $row["id"]; ?>"><?php echo $row["brand"]; ?></div> <?php echo "</td>";
			echo "<td>"; ?><div id="price<?php echo $row["id"]; ?>"><?php echo $row["price"]; ?></div> <?php echo "</td>";
			echo "<td>"; ?><div id="quantity<?php echo $row["id"]; ?>"><?php echo $row["quantity"]; ?></div> <?php echo "</td>";
			echo "<td>"; ?> <input type="button" id="<?php echo $row["id"]; ?>" name="<?php echo $row["id"]; ?>" value="delete" onclick="delete1(this.id)" class="button delet"> <?php echo "</td>";
		
			echo "<td>"; ?> 
			<input type="button" id="<?php echo $row["id"]; ?>" name="<?php echo $row["id"]; ?>" value="edit" onclick="aa(this.id)" class="button button2"> 
			<input type="button" id="update<?php echo $row["id"]; ?>" name="<?php echo $row["id"]; ?>" value="update" style="visibility:hidden" onclick="bb(this.name)" class="button button3">
			<?php echo "</td>";
		
		
		echo "</tr>";
	
		}
		echo "</table>";
	}
	
	
	
	if($status=="update")
	{
		$id=$_GET["id"];
		$details=$_GET["details"];
		$price=$_GET["price"];
		$quantity=$_GET["quantity"];
		$brand=$_GET["brand"];
	
		$details=trim($details);
		$price=trim($price);
		$quantity=trim($quantity);
		$brand=trim($brand);
		
		$res= updateProducts($brand,$id,$price,$quantity,$details);	
	}

if($status=="delete")
{
	$id=$_GET["id"];
	
	$res= deleteProduct($id);	
}

if($status=="ins")
{
	$type=$_GET["type"];
	$id=$_GET["id"];
	$details=$_GET["details"];
	$price=$_GET["price"];
	$brand=$_GET["brand"];
	$quantity=$_GET["quantity"];
	$image=$_GET["image"];
	//$type="mobile";
	
	$res= addProduct($type,$brand,$id,$price,$quantity,$details,$image);
}

if($status=="s"){
	//var_dump($status);
	if(isset($_GET['data']))
	{
		$val= $_GET["data"];
		$res = searchProduct($val);
		while($row=mysqli_fetch_assoc($res)){

			$pic = $row['image'];
			$p="../../images/";
		
			echo "<tr>";
			echo "<td>"; echo "<img src='".$p.$pic."'  height=100 width=100>"; echo "</td>";
			echo "<td>"; echo $row["id"]; echo "</td>";
			echo "<td>"; ?><div id="details<?php echo $row["id"]; ?>"><?php echo $row["details"]; ?></div> <?php echo "</td>";
			echo "<td>"; ?><div id="brand<?php echo $row["id"]; ?>"><?php echo $row["brand"]; ?></div> <?php echo "</td>";
			echo "<td>"; ?><div id="price<?php echo $row["id"]; ?>"><?php echo $row["price"]; ?></div> <?php echo "</td>";
			echo "<td>"; ?><div id="quantity<?php echo $row["id"]; ?>"><?php echo $row["quantity"]; ?></div> <?php echo "</td>";
			echo "<td>"; ?> <input type="button" id="<?php echo $row["id"]; ?>" name="<?php echo $row["id"]; ?>" value="delete" onclick="delete1(this.id)" class="button delet"> <?php echo "</td>";
		
			echo "<td>"; ?> 
			<input type="button" id="<?php echo $row["id"]; ?>" name="<?php echo $row["id"]; ?>" value="edit" onclick="aa(this.id)" class="button button2"> 
			<input type="button" id="update<?php echo $row["id"]; ?>" name="<?php echo $row["id"]; ?>" value="update" style="visibility:hidden" onclick="bb(this.name)" class="button button3">
			<?php echo "</td>";
		
		
		echo "</tr>";
	
		}
	}	
}	
	
?>













<!-- saved from url=(0035)http://127.0.0.1:81/mobo/admin.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"></head><body>
		<table width="100%">	
			<tbody><tr>
				<td align="center">
					<h1>Mobo Shop.Com</h1>
				</td>
			</tr>
			
			</tbody></table><table width="100%">
				<tbody><tr>
					<td align="center">
						<h2> Welcome Mr. X</h2>
                    </td>
                </tr>
                <tr>
                        <td align="right">
                            <input type="text" name="search_value"> 
                            <button name="search">
                                Search Products
                            </button>  
                        </td>
				</tr>
			</tbody></table>

            <br>
            <table width="100%">
                <tbody><tr>
                    <td align="center">
                        <button name="add">
                            Add <br> Products
                        </button>
                    </td>
                    <td align="center">
                        <button name="edit">
                            Edit <br>  Products
                        </button>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <button name="remove">
                            Remove <br>  Products
                        </button>
                    </td>
                    <td align="center">
                        <button name="settings">
                            Account <br>  Settings
                        </button>
                    </td>
                </tr>
                <tr>
                    <td> </td>
                    <td align="center">
                        <button name="logout">
                            Logout
                        </button>
                </td></tr>
            </tbody></table>

		
	

</body></html>
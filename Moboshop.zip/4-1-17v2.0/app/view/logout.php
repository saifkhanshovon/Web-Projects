<?php
	session_start();
	session_destroy();
	setcookie("user", "", time()-1);
	//setcookie("user", $_SESSION['user'][0], time()-1);
	header("location:home.php");
?>

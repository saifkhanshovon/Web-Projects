<html>
	<body>
		<table width=90% align="center" >
			<tr>

<?php
$link=mysqli_connect("localhost","root","");
	mysqli_select_db($link,"moboshop");
	$sql=mysqli_query($link,"SELECT * FROM product ORDER BY id DESC LIMIT 5");
	while ($row = mysqli_fetch_assoc($sql)) {
			$pic = $row['image'];
			$p="../../images/";
			$id = $row['id'];
			?>
			<td align="center">
				<?php echo "<img src='".$p.$pic."'  height=150 width=150>"; ?>
				
				<form   method="POST" action="productUser.php">
					<input type="text" name="valueToSearch" value="<?php echo "$id"; ?>" style="display: none;"/>
					<input type="submit" name="search" value="view Product">			
				</form>			
<?php			
			echo "</td>";				
		}
		

			
			
?>

			</tr>
		</table>
		
		
<script type="text/javascript">
	function searchProduct(){
		var sproduct = document.getElementById('search_value').value;
		//alert("Product Added to Cart");
		$.post('productAdmin.php',{value:sproduct},
		function(){
			$('#result').html(data);
		} );
	}
</script>
	</body>
</html>

 
<!--<!DOCTYPE HTML PUBLIC "-//w3c//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">-->

<?php 

	
	//header("location:home.php");
	if(!isset($_COOKIE['user'])){
		header("location:home.php");
		
	}
	
	
	session_start();
	$pid="all product";
	if ( ! empty($_POST['valueToSearch'])){
    $pid = $_POST['valueToSearch'];
	}
	$productSelect="";
	if(isset($_GET['value'])){
		$pid=$_GET['value'];
		var_dump($pid);
	}
	if(isset($_COOKIE['user'])){
		if($_SESSION['user']=="user"){
			header("location:home.php");
		}
		
	}
	
?>

<html>


	<head>

	<title>Untitled Document</title>
	<style>
		.add {
			font-size: 25px;
			border-radius: 5px;
			background-color: #4CAF50;
			color: #FFFFFF;
			
		}
		
		.home {
			font-size: 25px;
			border-radius: 5px;
			//background-color: #F08080;
			color: #FFFFFF;
			
		}
		.cart {
			font-size: 25px;
			border-radius: 5px;
			background-color: Gold;
			color: #FFFFFF;
			
		}
		
	</style>
	
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	</head>

	<body>

		
		<form name="form1" action="" method="post">

			<table width=100% align="center">
				<tr>
					<td align="center">
						<h1>Mobo Shop.Com</h1>
						<hr><hr>
					</td>
				</tr>
			</table></br>
			
			<table class="tes" width= 100% style="border-spacing: 5px;color: #FFFFFF;background-color: SteelBlue;">
			<tr >
				<td align="left" >
						
						<a href="home.php"><button type="button" class="button home" style="background-color: #F08080;">Home</button></a>
				</td>
				<td>
					</br>
					
					<input type="text" id="srch" name="srch" value="<?php echo "$pid"; ?>" style="display: none;"/>
					<input type="text" id="searchbox" placeholder="search product"/>
					<input type="button" id="searchbutton" onclick="searchProduct();" value="search"/><br/>
					<input type="file" id="upload" style="font-size: 15px;"/>
					<input type="text" id="txttypeins" placeholder="Type" style="font-size: 15px;">
					<input type="text" id="txtidins" placeholder="Model" style="font-size: 15px;">
					<input type="text" id="txtdetailsins" placeholder="Details" style="font-size: 15px;">
					<input type="text" id="txtbrandins" placeholder="Brand" style="font-size: 15px;">
					<input type="text" id="txtpriceins" placeholder="Price" style="font-size: 15px;">
					<input type="text" id="txtquantityins" placeholder="Stock"  style="font-size: 15px;">
					<input type="button" id="but1" value="Add Product" onclick="ins();" style="font-size: 25px;background-color: #4CAF50;color: #FFFFFF;border-radius: 5px;">
				</td>
				<td align="right">
						
						<a href="invoice.php"><button type="button" class="button home" style="background-color: #4CAF50;">Envoice</button></a>
			</td>
			</tr>
			</table>
			<div id="disp_data"></div>
		
		</form>
			

<script type="text/javascript">
//disp_data();

//alert(indexPage);
var x=document.getElementById('srch').value;
//alert(x);
if(x=="all product"){
	
	disp_data();
}
else{
	
	searchP();
}

function disp_data()
{
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.open("GET","productAdmin.php?status=disp",false);
	xmlhttp.send(null);
	document.getElementById("disp_data").innerHTML=xmlhttp.responseText;
	
}


function aa(a)
{
	detailsid="details"+a;
	txtdetailsid="txtdetails"+a;
	var details=document.getElementById(detailsid).innerHTML;
	document.getElementById(detailsid).innerHTML="<input type='text' value='"+details+"' id='"+txtdetailsid+"'>";
	
	priceid="price"+a;
	txtpriceid="txtprice"+a;
	var price=document.getElementById(priceid).innerHTML;
	document.getElementById(priceid).innerHTML="<input type='text' value='"+price+"' id='"+txtpriceid+"'>";
	
	quantityid="quantity"+a;
	txtquantityid="txtquantity"+a;
	var quantity=document.getElementById(quantityid).innerHTML;
	document.getElementById(quantityid).innerHTML="<input type='text' value='"+quantity+"' id='"+txtquantityid+"'>";
	
	brandid="brand"+a;
	txtbrandid="txtbrand"+a;
	var brand=document.getElementById(brandid).innerHTML;
	document.getElementById(brandid).innerHTML="<input type='text' value='"+brand+"' id='"+txtbrandid+"'>";

	updateid="update"+a;
	document.getElementById(a).style.visibility="hidden";
	document.getElementById(updateid).style.visibility="visible";
	
}

function bb(b)
{
	var detailsid="txtdetails"+b;
	var details=document.getElementById(detailsid).value;
	
	var priceid="txtprice"+b;
	var price=document.getElementById(priceid).value;
	
	var quantityid="txtquantity"+b;
	var quantity=document.getElementById(quantityid).value;
	
	var brandid="txtbrand"+b;
	var brand=document.getElementById(brandid).value;
	
	
	update_value(b,details,price,quantity,brand);
	
	document.getElementById(b).style.visibility="visible";
	document.getElementById("update"+b).style.visibility="hidden";
	
	document.getElementById("details"+b).innerHTML=details;
	document.getElementById("price"+b).innerHTML=price;
	document.getElementById("quantity"+b).innerHTML=quantity;
	document.getElementById("brand"+b).innerHTML=brand;
}

function update_value(id,details,price,quantity,brand)
{
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.open("GET","productAdmin.php?id="+id+"&details="+details+"&price="+price+"&quantity="+quantity+"&brand="+brand+"&status=update",false);
	xmlhttp.send(null);
}

function delete1(id)
{
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.open("GET","productAdmin.php?id="+id+"&status=delete",false);
	xmlhttp.send(null);
	disp_data();
}

function ins()
{	
	var fullPath = document.getElementById('upload').value;
	if (fullPath) {
		var startIndex = (fullPath.indexOf('\\') >= 0 ? fullPath.lastIndexOf('\\') : fullPath.lastIndexOf('/'));
		var filename = fullPath.substring(startIndex);
		if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
        filename = filename.substring(1);
    }
    //alert(filename);
}
	var type=document.getElementById("txttypeins").value;
	var id=document.getElementById("txtidins").value;
	var details=document.getElementById("txtdetailsins").value;
	var price=document.getElementById("txtpriceins").value;
	var brand=document.getElementById("txtbrandins").value;
	var quantity=document.getElementById("txtquantityins").value;
	
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.open("GET","productAdmin.php?type="+type+"&id="+id+"&details="+details+"&price="+price+"&brand="+brand+"&quantity="+quantity+"&image="+filename+"&status=ins",false);
	xmlhttp.send(null);
	
	disp_data();
	
	document.getElementById("txttypeins").value="";
	document.getElementById("txtidins").value="";
	document.getElementById("txtdetailsins").value="";
	document.getElementById("txtpriceins").value="";
	document.getElementById("txtbrandins").value="";
	document.getElementById("txtquantityins").value="";
}

function searchProduct(){
	
	
		var sproduct = document.getElementById('searchbox').value;
		alert(sproduct);
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.open("GET","productAdmin.php?data="+sproduct+"&status=s",false);
		xmlhttp.send(null);
		document.getElementById("disp_data").innerHTML=xmlhttp.responseText;
	
}

function searchP(){
	
	
		var sproduct = document.getElementById('srch').value;
		//alert(sproduct);
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.open("GET","productAdmin.php?data="+sproduct+"&status=s",false);
		xmlhttp.send(null);
		document.getElementById("disp_data").innerHTML=xmlhttp.responseText;
	
}


</script>

</body>
</html>
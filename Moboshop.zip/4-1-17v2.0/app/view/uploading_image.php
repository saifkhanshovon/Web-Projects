<?php require_once("../../data/product_data_access.php") ?>
<?php

	if(isset($_POST['upload'])){
		$target=basename($_FILES['image']['name']);


		$name = $_POST['f_name_text'];
		$val = $_POST['price_text'];
		$int=(int)$val;
		$image=$_FILES['image']['name'];
		addProductsToDb($name,$int,$image);
		
		
	}



?>

<html>
  <body>
		<form method="post" action="uploading_image.php" enctype="multipart/form-data">
		<input type="hidden" name ="size" value="1000000">
		
		<input type="file" name="image" />
		

		
		
		
		<input type="submit" name="upload" value ="upload"/>
		
		</form>
  </body>
</html>
<?php include_once("../../core/person_service.php"); ?>
<?php
session_start();
$userEmail="Guest login";
$userName="Guest login";

if(isset($_COOKIE['user'])){
	$userEmail= $_COOKIE['user'];
	
	$res = getPerson($userEmail);
	while ($row = mysqli_fetch_assoc($res)) {
			$userName = $row["Name"];
		}
	
}
?>


<html>
<style>
	
		body{
			//background-color: CadetBlue;
		}
		table{
			border-collapse: collapse;
			text-align: center;
			
		}
		
		table th{
			text-align: center;
			background-color: #3a6070;
			color: #FFF;
			padding: 4px 30px 4px 8px;
		}
		
		table td{
			border: 1px solid #e3e3e3;
			padding: 4px 8px
		}
		
		table tr:nth-child(even) td{
			background-color: #e7edf0;
			

		}
		
		.X {
			border-radius: 12px;
			background-color: #f4511e;
			color: #FFFFFF;
			font-size: 20px;
			
		}
		.change {
			border-radius: 12px;
			background-color: #4CAF50;
			color: #FFFFFF;
			font-size: 15px;
			
		}
		
		.title{
			//border-style:double red;
			border: 2px solid;
			border-radius: 8px;
			outline-style: double;
			outline-color: green;
			outline-width: thick;
			//padding-right: 30px;
			margin-right: 5%;
			margin-left: 5%;

		}
		.home {
			font-size: 25px;
			border-radius: 5px;
			//background-color: #F08080;
			color: #FFFFFF;
			
		}
		
		
		
	</style>
</body>

		<br/>
	<div class="title" align="center">
		<p>
			<h1>Mobo Shop.com</h1>
		</p>
		
	</div>
	<br/>
	
	<table width=90% align="center" style="background-color: SteelBlue ;">
		<tr>
			<td align="left" >
						
						<a href="home.php"><button type="button" class="button home" style="background-color: #F08080;">Home</button></a>
			</td>
			<td align="right" >
						
						<a href="productUser.php?value=all product"><button type="button" class="button home" style="background-color: #4CAF50;">Product</button></a>
			</td>
		</tr>
	</table>
	<br/>
	
	<table width=80% align="center">
		<tr>
			<td>Client Name:<input type="text" value="<?php echo"$userName";?>"/></td>
			<td>Date:<script> document.write(new Date().toLocaleDateString()); </script></td>
		</tr>
		
		<tr>
			<td>Client Email:<input type="text" value="<?php echo"$userEmail";?>"/>
			<td>Order:<input type="text" value="0005"/>
		</tr>
	</table>
		<br/>
		<hr width=90% />

	<h2 align="center">My Cart:</h2>
	
	<table width=65% align="center">	
		<tr >
				<th>Model</th>
				<th>Price</th>
				<th>Quantity</th>
				<th>Total</th>
				<th>Delete</th>
			</tr>

</body>
</html>
<?php include_once("../../core/productService.php"); ?>
<?php

/////--------render the cart for the user to view on the page----------//////

if (!isset($_SESSION["cart_array"]) || count($_SESSION["cart_array"]) < 1) {
    $cartOutput = "<h2 align='center'>Your shopping cart is empty</h2>";
} else {

	$i = 0;
	 $cartTotal=0;
    foreach ($_SESSION["cart_array"] as $each_item) {
		$item_id = $each_item['item_id'];
		
		$sql=getProducts($item_id);
		//$sql=mysqli_query($link,"SELECT * FROM product WHERE id='$item_id'");
		
		while ($row = mysqli_fetch_assoc($sql)) {
			$product_name = $row["id"];
			$price = $row["price"];
			$details = $row["details"];
			$quantity = $each_item['quantity'];
		}
		
		$pricetotal = $price * $each_item['quantity'];
		$cartTotal = $pricetotal + $cartTotal;
		echo "<tr>";
			echo "<td>"; echo "$product_name";?> </td>
			<td> <?php echo "$price";?> </td>
			<td><form action="cartIndex.php" method="post">
					<input name="quantity" type="text" value="<?php echo "$quantity";?>" size="1" maxlength="2" />
					<input name="adjustBtn<?php echo "$item_id" ; ?>" type="submit" value="change" class="change" />
					<input name="item_to_adjust" type="hidden" value="<?php echo "$item_id" ; ?>" /> 
				</form>
			</td>
			<td><?php echo "$pricetotal";?> </td>
			<td><form action="cartIndex.php" method="post">
					<input name="deleteBtn<?php echo "$item_id" ; ?>" type="submit" value="X" class="X" />
					<input name="index_to_remove" type="hidden" value="<?php echo "$i" ; ?>" /> 
				</form>
			</td>
		</tr>
		
	<?php
	$i++;
	}
?>	
	</table>
	<table width=65% align="center">
	<tr>
		<td align="right"><h3> <?php echo "Grand Total : $cartTotal"; echo "</td>"; echo "</tr>";?>
		
	<tr>
		<td ><form action="cartIndex.php" method="post">
					<input name="buyBtn" type="submit" value="buy" class="change" />
				</form>
		</td>
	</tr>
		
	<?php echo "</table>";
		
}

?>


<?php 

/////-------- if user wants to remove an item from cart ----------//////

if (isset($_POST['index_to_remove']) && $_POST['index_to_remove'] != "") {
 	$key_to_remove = $_POST['index_to_remove'];
	if (count($_SESSION["cart_array"]) <= 1) {
		unset($_SESSION["cart_array"]);
	} else {
		unset($_SESSION["cart_array"]["$key_to_remove"]);
		sort($_SESSION["cart_array"]);
	}
	
	header("location: cartIndex.php"); 
    exit();
}
?>
<?php include_once("../../core/invoice.php"); ?>
<?php include_once("../../core/productService.php"); ?>
<?php 

/////--------if user chooses to adjust item quantity----------//////

if (isset($_POST['item_to_adjust']) && $_POST['item_to_adjust'] != "") {
	$item_to_adjust = $_POST['item_to_adjust'];
	$quantity = $_POST['quantity'];
	$quantity = preg_replace('#[^0-9]#i', '', $quantity); // filter everything but numbers
	if ($quantity >= 100) { $quantity = 99; }
	if ($quantity < 1) { $quantity = 1; }
	if ($quantity == "") { $quantity = 1; }
	$i = 0;
	foreach ($_SESSION["cart_array"] as $each_item) { 
		      $i++;
		      while (list($key, $value) = each($each_item)) {
				  if ($key == "item_id" && $value == $item_to_adjust) {
					  //  adjust  quantity using array_splice()
					  array_splice($_SESSION["cart_array"], $i-1, 1, array(array("item_id" => $item_to_adjust, "quantity" => $quantity)));
				  } 
		      } 
	} 
	
	header("location: cartIndex.php"); 
}

////------------------Buy Cart Product --------------//////////
if(isset($_POST['buyBtn'] ) ){
	if($userEmail=="Guest login"){
	echo "<script>alert('You have to log in first!!');</script>";
}
else{
	$i = 0;
	$reminder=true;
	foreach ($_SESSION["cart_array"] as $each_item) {
		$item_id = $each_item['item_id'];
		$quantity = $each_item['quantity'];
		
		//$link=mysqli_connect("localhost","root","");
		//mysqli_select_db($link,"moboshop");
		//$sql=mysqli_query($link,"SELECT * FROM product WHERE id='$item_id'");
		$sql=getProducts($item_id);
		while ($row = mysqli_fetch_assoc($sql)) {
			$quantityTable = $row['quantity'];
			if($quantityTable<$quantity)
				$reminder=false;
		}
		
	$i++;
	}
	
	if($reminder){

		$i = 0;
		foreach ($_SESSION["cart_array"] as $each_item) {
			$item_id = $each_item['item_id'];
			$quantity = $each_item['quantity'];
		
			$sql2=getProducts($item_id);
		
			while ($row = mysqli_fetch_assoc($sql2)) {
				$quantityTable = $row['quantity'];
				$quantityTable=$quantityTable-$quantity;
				$sql3=updateProductsForCart($quantityTable);
				//$sql3=mysqli_query($link,"update product set quantity='$quantityTable' where id='$item_id'");
			}
		
		$i++;
		}
		
			invoiceTable($userName, $userEmail,$cartTotal);
		//echo "<script>alert('Order Successfull...We prfer cash on delivery. Thak you.!!');</script>";
		unset($_SESSION["cart_array"]);

		header("location: home.php"); 
	}
	
	else{
		echo "<script>alert('Product  of Stooutct!!');</script>";
	}
}
	
}





?>





<?php 	
	
	
	function executeNonQuery($query){
		//global $serverName, $userName, $password, $dbName;
		$serverName = "127.0.0.1:3306";
		$userName = "root";
		$password = '';
		$dbName = "moboshop";
		$result = false;
		$connection = mysqli_connect($serverName, $userName, $password, $dbName);		
		if($connection){
			$result = mysqli_query($connection, $query);
			mysqli_close($connection);
		}
		return $result;
	}
	
	function executeQuery($query){
		return executeNonQuery($query);	
	}
?>
<?php include_once("../../data/invoice_data_acces.php"); ?>
<?php
	function invoiceTable($userName, $userEmail, $cartTotal){
		return invoiceTableToDb($userName, $userEmail, $cartTotal);
	}
	function getAllEnvoice(){
		$allEnvoice= getEnvoice();
		return $allEnvoice;
	}
	
?>
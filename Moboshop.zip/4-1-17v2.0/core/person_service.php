<?php include_once("../../data/person_data_access.php"); ?>
<?php
	
	function login($person){
		$email= $person['email'];
		$password= $person['password'];
		
		$data= getAllPassword($email,$password);
		//echo "$x";
		if($data["password"]==$password){
			
			return $data;
			//header("location: home.php");
			
		}
		else{
			return false;
		}
		
	}
	
	function addUser($person){
		return addPersonToDb($person);
	}
	
	function accountSettings($person){
		return accountSettingsToDb($person);
	}
	
	function getPerson($email){
		return getPersonFromDb($email);
	}
	
?>
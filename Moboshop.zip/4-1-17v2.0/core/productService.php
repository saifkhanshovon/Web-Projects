<?php include_once("../../data/product_data_access.php"); ?>
<?php

	
	function getAllProducts(){
		$allProducts= getProduct();
		return $allProducts;
	}
	
	function updateProducts($brand,$id,$price,$quantity,$details){
		$updateProducts= updateItem($brand,$id,$price,$quantity,$details);
		return $updateProducts;
	}
	
	function deleteProduct($id){
		$deleteProduct= deleteItem($id);
		return $deleteProduct;
	}
	
	function addProduct($type,$brand,$id,$price,$quantity,$details,$image){
		$addProduct= addItem($type,$brand,$id,$price,$quantity,$details,$image);
		return $addProduct;
	}
	
	function searchProduct($search){
		$searchResult=searchProductFromDb($search);
		return $searchResult;
	}
	function searchProductByType($search){
		$searchResult=searchProductByTypeFromDb($search);
		return $searchResult;
	}
	function updateProductsForCart($value){
		return updateProductForCartDb($value);
	}
	function getProducts($v){
		$searchResult=searchProductFromDbForcart($v);
		return $searchResult;
	}

?>
const express = require('express');
const connectFarmBot = require('../farmbot/connectFarmBot')
const bodyParser = require("body-parser");

const jobsRouter = require("./jobsRouter");
const sendStatusRouter = require("./sendStatus");
const plantGroupsRouter = require('./plantGroupsRouter');

const app = express();
const PORT = 3000;

// Initialize farmbot connection with the server
connectFarmBot().catch((err) => console.log("FARMBOT CONNECTION ERROR: ", err));

//Here we are configuring express to use body-parser as middle-ware.
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// This defines the folder to be accessed to get the static files to render on the / page
// To get the exampleWebpage got to /exampleWebpage.html
app.use(express.static(__dirname + '\\..\\frontend'));

app.use("/jobs", jobsRouter);
app.use("/", sendStatusRouter);
app.use('/', plantGroupsRouter);

app.get('/', (req, res) => {
  console.log('Hello World!')
});

app.listen(PORT, () => console.log(`Server listening on port: ${PORT}`));

module.exports = app;
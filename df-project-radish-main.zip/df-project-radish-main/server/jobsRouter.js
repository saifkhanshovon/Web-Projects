const express = require("express");
const router = express.Router();
const store = require("../redux/store");

const initiateAgenda = require("../scheduling/agenda")
const connect = require("../farmbot-db/connectFarmBotDB")

const seedingJobsRouter = require('./seedingJobsRouter');
const wateringJobsRouter = require('./wateringJobsRouter');

const { boundDBActions } = require("../redux/actions");

let dbClient;
connect().then((client) => {
  dbClient = client;
  boundDBActions.connectDB({ dbClient: client })
  console.log("DB client saved.")

  initiateAgenda(dbClient).then((agenda) => {
    boundDBActions.connectAgend({ agenda: agenda })
    console.log("Agenda client saved.");

    agenda
      .start()
      .then(() => console.log("Scheduler is running."));
  })
});

router.use('/', seedingJobsRouter);
router.use('/', wateringJobsRouter);


router.get('/schedule', (req, res) => {
  store.getState().agenda.jobs()
    .then(result => {
      //console.log('Current jobs scheduled:', result);
      res.status(200).send({ result });
    })
});

router.delete('/schedule', (req, res) => {
  store.getState().agenda.cancel()
    .then(result => {
      //console.log('Current jobs scheduled:', result);
      res.status(200).send({ result });
    })
});

module.exports = router;
const router = require("express").Router();
const store = require("../redux/store");

let clients = [];
router.get('/status', (request, response) => {
    // Set response headers
    const headers = {
        'Content-Type': 'text/event-stream',
        'Connection': 'keep-alive',
        'Cache-Control': 'no-cache'
    };
    response.writeHead(200, headers);

    // Structure state properties to be sent to client
    const { position, busy, idle } = store.getState();
    const state = { position, busy, idle };
    const data = `data: ${JSON.stringify(state)}\n\n`;

    response.write(data);

    // Save client 
    const clientId = Date.now();

    const newClient = {
        id: clientId,
        response
    };
    clients.push(newClient);

    // Subscribe to store changes to update clients
    store.subscribe(() => {
        const { position, busy, idle, log } = store.getState();
        const state = { position, busy, idle, log };
        clients.forEach(client => client.response.write(`data: ${JSON.stringify(state)}\n\n`))
    })

    // Close connection if requested
    request.on('close', () => {
        console.log(`${clientId} Connection closed`);
        clients = clients.filter(client => client.id !== clientId);
    });
})

module.exports = router;
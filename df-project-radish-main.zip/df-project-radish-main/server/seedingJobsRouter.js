const express = require("express");
const router = express.Router();
const store = require("../redux/store");

const { addSeedingJob, getSeedingJob, getAllSeedingJobs, removeSeedingJob, removeAllSeedingJobs } = require("../farmbot-db/seedingJob");
const { grid } = require("./seedingPatterns");

const getDBClient = () => store.getState().dbClient;

router.get('/seeding', (req, res) => {
    getAllSeedingJobs(getDBClient())
        .then((result) => {
            res.status(200).json(result);
        });
});

router.get('/seeding/:id', (req, res) => {
    console.log("Requested Seeding Job ID: ", req.params.id);
    getSeedingJob(getDBClient(), req.params.id)
        .then((job) => {
            if (job) {
                store.getState().agenda.now("seeding", { id: req.params.id })
                    .then(() => {
                        console.log('Job %s scheduled NOW', req.params.id);
                        res.status(200).send();
                    });
            } else {
                res.status(400).send();
            }
        })
});

router.post('/seeding', (req, res) => {
    console.log(req.body);

    const job = req.body;
    job.points = grid(parseInt(job['x1']), parseInt(job['y1']), parseInt(job['x2']), parseInt(job['y2']), parseInt(job['density']));

    if (job.points.length !== 0) {
        console.log(job);
        const resultId = addSeedingJob(getDBClient(), job);

        return res.status(200).send({ id: resultId });
    } else {
        return res.status(400).send({ message: 'No seeding points created. Seeding job parameters need to be adjusted!' });
    }
});

router.delete('/seeding', (req, res) => {
    removeAllSeedingJobs(getDBClient()).then(() => {
        return res.status(200).send();
    });
});

router.delete('/seeding/:id', (req, res) => {
    removeSeedingJob(getDBClient(), req.params.id)
        .then(() => {
            return res.status(200).send();
        });
});


module.exports = router;
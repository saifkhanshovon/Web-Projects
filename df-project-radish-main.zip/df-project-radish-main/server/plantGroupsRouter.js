const express = require("express");
const router = express.Router();
const store = require("../redux/store");

const { addPlantGroup, getAllPlantGroups, getPlantGroup, removePlantGroup, removeAllPlantGroups } = require("../farmbot-db/plantGroup");

const getDBClient = () => store.getState().dbClient;

router.get('/plant-groups', (req, res) => {
    getAllPlantGroups(getDBClient())
        .then((result) => {
            res.status(200).json(result);
        });
});

router.get('/plant-groups/:id', (req, res) => {
    console.log("Requested plant group ID: ", req.params.id);
    getPlantGroup(getDBClient(), req.params.id)
        .then((result) => {
            if (result) {
                res.status(200).json(result);
            } else {
                res.status(400);
            }
        })
});

router.post('/plant-groups', (req, res) => {
    console.log(req.body);

    const job = req.body;

    const resultId = addPlantGroup(getDBClient(), job);

    return res.status(200).send({ id: resultId });

    //return res.status(400).send({ message: 'No plant group created. Plant group parameters need to be adjusted!' });
});

router.delete('/plant-groups', (req, res) => {
    removeAllPlantGroups(getDBClient()).then(() => {
        return res.status(200).send();
    });
});

router.delete('/plant-groups/:id', (req, res) => {
    removePlantGroup(getDBClient(), req.params.id)
        .then(() => {
            return res.status(200).send();
        });
})

module.exports = router;
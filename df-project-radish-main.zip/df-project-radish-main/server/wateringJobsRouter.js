const express = require("express");
const router = express.Router();
const store = require("../redux/store");

const { addWateringJob, getWateringJob, getAllWateringJobs, removeWateringJob, removeAllWateringJobs, changeWateringJobActiveState } = require("../farmbot-db/wateringJob");

const getDBClient = () => store.getState().dbClient;

router.get('/watering', (req, res) => {
    getAllWateringJobs(getDBClient())
        .then((result) => {
            res.status(200).json(result);
        });
});

router.get('/watering/:id', (req, res) => {
    console.log("Requested Watering Job ID: ", req.params.id);
    getWateringJob(getDBClient(), req.params.id)
        .then((job) => {
            if (job) {
              store.getState().agenda.now(
                "watering",
                { id: req.params.id })
                .then(() => {
                  console.log('Job %s scheduled NOW', req.params.id);
                  res.status(200).send();
                });
            } else {
                res.status(400).send();
            }
        })
});

router.post('/watering', (req, res) => {
  console.log(req.body);

  const job = req.body;

  console.log(job);

  addWateringJob(getDBClient(), job)
    .then((jobId) => {
      if (jobId) {
        store.getState().agenda.every(
          `${job.hours} minutes`,
          "watering",
          { id: jobId },
          {
            skipImmediate: false,
            startDate: `${job.date} ${job.time}`,
            shouldSaveResult: true,
            timezone: 'Europe/Berlin'
          })
          .then(() => {
            console.log('Job %s scheduled for %s every %s minutes', jobId, `${job.date} ${job.time}`, job.hours);
            res.status(200).send({ id: jobId });
          });
      } else {
        res.status(400).send();
      }
    })

    //return res.status(200).send({ id: resultId });

    //return res.status(400).send({ message: 'No watering job created. Watering job parameters need to be adjusted!' });
});

router.delete('/watering', (req, res) => {
    removeAllWateringJobs(getDBClient()).then(() => {
        return res.status(200).send();
    });
});

router.delete('/watering/:id', (req, res) => {
    removeWateringJob(getDBClient(), req.params.id)
        .then(() => {
            return res.status(200).send();
        });
})

router.post('/watering/:id', (req, res) => {
    console.log("Requested Watering Job ID: ", req.params.id);
    console.log("Requested Watering Job State: ", req.body.active);
    getWateringJob(getDBClient(), req.params.id)
        .then((job) => {
            if (job) {
                changeWateringJobActiveState(getDBClient(), req.params.id, req.body.active)
                    .then(r => res.status(200).send(r))
                    .catch(r => res.status(400).send(r))
            } else {
                res.status(400);
            }
        })
});

module.exports = router;
/**
 * Calculation of points pattern of a grid in the area defined by the input.
 * Input need to be integer!
 * @param xStart
 * @param yStart
 * @param xEnd
 * @param yEnd
 * @param density
 * @returns {*[]} Array of points {x, y}
 */
function grid(xStart, yStart, xEnd, yEnd, density) {
    const points = [];

    // Make sure the start value is always smaller than the end value
    if (xStart > xEnd) {
        const temp = xStart;
        xStart = xEnd;
        xEnd = temp;
    }
    if (yStart > yEnd) {
        const temp = yStart;
        yStart = yEnd;
        yEnd = temp;
    }

    const areaPerPlant = 1000000/density;
    let xCount = Math.round((xEnd-xStart)/Math.sqrt(areaPerPlant));
    const xyCount = Math.floor((yEnd-yStart)/(areaPerPlant/((xEnd-xStart)/xCount)));
    let yCount = Math.round((yEnd-yStart)/Math.sqrt(areaPerPlant));
    const yxCount = Math.floor((xEnd-xStart)/(areaPerPlant/((yEnd-yStart)/yCount)));

    if ((xCount * xyCount) > 0) {
        if ((yCount * yxCount) > 0) {
            console.log(`Options: ${xCount} x ${xyCount} or ${yxCount} x ${yCount}`);

            //Decision which pattern to choose
            if ((xCount * xyCount) >= (yCount * yxCount)) {
                yCount = xyCount;
            } else {
                xCount = yxCount;
            }
        } else {
            yCount = xyCount;
        }
    } else if ((yCount * yxCount) > 0) {
        xCount = yxCount;
    } else {
        console.log(`No points created!`)
        return points;
    }

    console.log(`Pattern: ${xCount} x ${yCount}`);

    const xDist = (xEnd-xStart)/xCount, yDist = (yEnd-yStart)/yCount;
    let x = xStart + xDist / 2, y = yStart + yDist / 2;

    // Creating points
    while(x <= xEnd) {
        while(y <= yEnd) {
            const point = {'x': Math.round(x), 'y': Math.round(y)};
            points.push(point);

            y += yDist;
        }

        x += xDist;
        y = yStart+yDist/2;
    }

    return points;
}

module.exports = {grid}
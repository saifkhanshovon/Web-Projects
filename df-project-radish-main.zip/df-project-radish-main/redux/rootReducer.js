const initialState = {
    isFarmbotConnected: false
};

const rootReducer = (state = initialState, action) => {
    const { type, payload } = action;
    switch (type) {
        case 'FARMBOT_CONNECTED':
            return { ...state, isFarmbotConnected: true }
        case 'FARMBOT_DISCONNECTED':
            return { ...state, isFarmbotConnected: false }
        case 'FARMBOT_STATUS_RECEIVED':
            return { ...state, ...payload }
        case 'DB_CONNECTED':
            return { ...state, ...payload }
        case 'AGEND_CONNECTED':
            return { ...state, ...payload }
        case 'LOG_RECEIVED':
            return { ...state, ...payload }
        default:
            return state
    }
}

module.exports = rootReducer;
const { bindActionCreators } = require("redux");
const store = require("./store");

const farmbotConnected = () => ({ type: 'FARMBOT_CONNECTED' });

const farmbotDisconnected = () => ({ type: 'FARMBOT_DISCONNECTED' });

const farmbotStatusReceived = (payload) => ({ type: 'FARMBOT_STATUS_RECEIVED', payload });

const dbConnected = (payload) => ({ type: 'DB_CONNECTED', payload });

const agendConnected = (payload) => ({ type: 'AGEND_CONNECTED', payload });

const logReceived = (payload) => ({ type: 'LOG_RECEIVED', payload });

const boundFarmBotActions = bindActionCreators(
    {
        connect: farmbotConnected,
        disconnect: farmbotDisconnected,
        receiveStatus: farmbotStatusReceived
    },
    store.dispatch
);

const boundDBActions = bindActionCreators(
    {
        connectDB: dbConnected,
        connectAgend: agendConnected
    },
    store.dispatch
)

const boundLogActions = bindActionCreators(
    {
        receiveLog: logReceived
    },
    store.dispatch
)
// now we have an object with all the same keys
// where each key is now a pre-bound function
// we can just call directly. And it will dispatch
// the necessary action.
// boundFarmBotActions.connect()
// boundFarmBotActions.disconnect()
// boundFarmBotActions.receiveStatus(newStatus)

module.exports = { boundFarmBotActions, boundDBActions, boundLogActions };
const Agenda = require("agenda");
const { getSeedingJob } = require("../farmbot-db/seedingJob");
const { getWateringJob } = require("../farmbot-db/wateringJob");
const store = require("../redux/store");
const { seedPlantGroup, waterPlantGroup } = require("../farmbot/executeBasicJob");
const { changePlantGroupPlantedState } = require("../farmbot-db/plantGroup");

async function initiateAgenda(dbClient) {
	const agenda = await new Agenda({
		mongo: dbClient.db("jobs"),
		maxConcurrency: 1,									// only one job can be executed at the same time
		defaultLockLifetime: 3600000,						// job have 1h to be finished
		processEvery: "5 seconds",
		defaultShouldSaveResult: true
	});

	agenda.define("seeding", async (job, done) => {
		// Search for specified seeding job in DB
		const seedingJob = await getSeedingJob(dbClient, job.attrs.data.id);

		// execute it!
		seedPlantGroup(store.getState().fb, seedingJob)
			.then(() => changePlantGroupPlantedState(dbClient, seedingJob.points, true)
				.then(() => done()))
			.catch((err) => done(new Error(`Farmbot error: ${err.message}`)));
	});

	agenda.define("watering", async (job, done) => {
		// Search for specified seeding job in DB
		const wateringJob = await getWateringJob(dbClient, job.attrs.data.id);

		if (wateringJob.active) {
			console.log(`Now executing watering job: ${wateringJob.name} (ID: ${job.attrs.data.id})`);

			// execute it!
			waterPlantGroup(store.getState().fb, wateringJob)
				.then(() => done())
		} else {
			done();
		}
	});

	agenda.on("start", (job) => {
		// Check if Farmbot is connected
		if (store.getState().isFarmbotConnected) {
			console.log(`Now executing job: '${job.attrs.name}' (ID ${job.attrs.data.id})`);
		} else {
			job.done(new Error(`Farmbot isn't connected!`));
		}
	});

	agenda.on("success", (job) => {
		console.log(`Job '${job.attrs.name}' (ID ${job.attrs.data.id}) finished successfully`);
	});

	agenda.on("fail", (err, job) => {
		console.log(`Job '${job.attrs.name}' failed with error: ${err.message}`);
	});

	return agenda;
}

module.exports = initiateAgenda;
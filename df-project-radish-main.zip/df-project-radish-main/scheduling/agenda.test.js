const initiateAgenda = require("./agenda")
const { connect } = require("../farmbot-db/farmbotDB");


let dbClient;
connect().then(async (client) => {
	dbClient = client;
	console.log("DB Client saved.")

	const agenda = await initiateAgenda(client);

	await agenda.start();
	await agenda.cancel();


	(async function () {
		// IIFE to give access to async/await
		//await agenda.start();

		//await agenda.every("10 seconds", "seeding", { id: '622896e9bac415157e25744c' });

		// Alternatively, you could also do:
		//await agenda.every("*/3 * * * *", "delete old users");
	})();
});

/*
let dbClient;
connect().then((client) => {
	dbClient = client;
	console.log("DB Client saved.")

	initiateAgenda(dbClient).then((agenda) => {
		console.log(agenda)

		agenda.define("print sth", async (job) => {
			console.log("Hello!")
		})

		(async function () {
			await agenda.start();

			await agenda.every("30 seconds", "print sth");
		})();
	});

});


 */

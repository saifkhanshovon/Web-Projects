# df-project-radish

Digital Farming Project - Group Radish

## Start Node server
`npm start`

## Run Jest tests
`npm test`

##hi
const store = require("../redux/store");
const { getPlantGroup } = require("../farmbot-db/plantGroup");
const { boundLogActions } = require("../redux/actions");

const GROUNDLEVEL = -480;
const SAVEHEIGHT = -250;
const SEEDS_Z = -270;
const VACUUMPIN = 9;
const WATERPIN = 8;

/**
 * Taking a connected FarmBot, moving to seeds and picking up one with the vacuum, endposition is at SAVEHEIGHT
 * @param fb
 * @param plantType
 * @returns {Promise<RpcOk | RpcError | RpcOk | RpcError>}
 */
async function collectSeed(fb, plantType) {
  const { position: { x, y } } = store.getState();
  console.log(`Collecting a seed: ${plantType}`);
  // Dispatch action to update log state
  boundLogActions.receiveLog({ log: { type: 'info', message: `Fetching ${plantType} seed.` } });

  return fb.moveAbsolute({ x: x, y: y, z: SAVEHEIGHT, speed: 100 })
    .then(() => fb.moveAbsolute({ x: x, y: 0, z: SAVEHEIGHT, speed: 100 }))
    .then(() => fb.moveAbsolute({ x: x, y: 0, z: SEEDS_Z, speed: 100 }))
    .then(() => fb.togglePin({ pin_number: VACUUMPIN }))
    .then(() => fb.moveAbsolute({ x: x, y: 0, z: SAVEHEIGHT, speed: 100 }));
}

/**
 * Taking a connected FarmBot, moving to X and Y position
 * @param fb
 * @param posX
 * @param posY
 * @returns {Promise<RpcOk | RpcError | RpcOk | RpcError>}
 */
async function moveToPos(fb, posX, posY) {
  return await moveToPosAtHeight(fb, posX, posY, store.getState().position.z);
}

/**
 * Taking a connected FarmBot, moving to X and Y position at a specified height
 * @param fb
 * @param posX
 * @param posY
 * @param height
 * @returns {Promise<RpcOk | RpcError | RpcOk | RpcError>}
 */
async function moveToPosAtHeight(fb, posX, posY, height) {
  console.log(`Moving to (${posX}, ${posY}), at ${height}`);
  // Dispatch action to update log state
  boundLogActions.receiveLog({ log: { type: 'info', message: `Moving to (${posX}, ${posY})` } });

  return fb.moveAbsolute({ x: store.getState().position.x, y: store.getState().position.y, z: height, speed: 100 })
    .then(() => fb.moveAbsolute({ x: posX, y: posY, z: height, speed: 100 }));
}

/**
 * Taking a connected FarmBot, moving to X and Y position
 * @param fb
 * @param posX
 * @param posY
 * @returns {Promise<RpcOk | RpcError | RpcOk | RpcError>}
 */
async function moveToPosAtSaveHeight(fb, posX, posY) {
  return await moveToPosAtHeight(fb, posX, posY, SAVEHEIGHT);
}

/**
 * Taking a connected FarmBot, moving to depth referring GROUNDLEVEL and turning vacuum off
 * @param fb
 * @param depth
 * @returns {Promise<RpcOk | RpcError | RpcOk | RpcError>}
 */
async function seedAtCurrentPos(fb, depth) {
  const { position: { x, y } } = store.getState();
  console.log(`Seeding at (${x}, ${y}), depth: ${depth}`);
  // Dispatch action to update log state
  boundLogActions.receiveLog({
    log: {
      type: 'info',
      message: `Seeding at (${x}, ${y}), depth: ${depth}`
    }
  });

  return fb.moveAbsolute({ x: x, y: y, z: GROUNDLEVEL - depth, speed: 100 })
    .then(() => fb.togglePin({ pin_number: VACUUMPIN }))
    .then(() => fb.moveAbsolute({ x: x, y: y, z: SAVEHEIGHT, speed: 100 }));
}

/**
 * Taking a connected FarmBot, moving to depth referring GROUNDLEVEL and turning vacuum off
 * @param fb
 * @param height
 * @param amount
 * @returns {Promise<RpcOk | RpcError | RpcOk | RpcError>}
 */
async function waterAtCurrentPos(fb, height, amount) {
  const duration = amount / 62;
  const { position: { x, y } } = store.getState();
  console.log(`Watering ${amount}ml (${Math.trunc(duration)}s) at (${store.getState().position.x}, ${store.getState().position.y}), height: ${height}`);
  // Dispatch action to update log state
  boundLogActions.receiveLog({ log: { type: 'info', message: `Watering at (${x}, ${y}), height: ${height}` } });

  const awaitTimeout = delay =>
    new Promise(resolve => setTimeout(resolve, delay));

  return fb.moveAbsolute({ x: x, y: y, z: GROUNDLEVEL + height, speed: 100 })
    .then(() => fb.togglePin({ pin_number: WATERPIN }))
    .then(() => awaitTimeout(duration))
    .then(() => fb.togglePin({ pin_number: WATERPIN }));
}

/**
 * Taking a connected FarmBot and seeding at all positions of the given Seeding Job
 * @param fb
 * @param seedingJob
 * @returns {Promise<void>}
 */
async function seedPlantGroup(fb, seedingJob) {
  console.log(`Now seeding: ${seedingJob.plantType}`);
  // Dispatch action to update log state
  boundLogActions.receiveLog({ log: { type: 'info', message: `Now seeding: ${seedingJob.plantType}` } });

  const plants = await getPlantGroup(store.getState().dbClient, seedingJob.points);
  console.log('Points: ', plants.points);

  async function loop(n) {
    for (let i = 0; i < n; i++) {
      await collectSeed(fb, seedingJob.plantType)
        .then(() => moveToPosAtSaveHeight(fb, plants.points[i].x, plants.points[i].y))
        .then(() => seedAtCurrentPos(fb, seedingJob.depth));
    }
  }

  return await loop(plants.points.length)
    .then(() => Promise.resolve());
}

/**
 * Taking a connected FarmBot and seeding at all positions of the given Seeding Job
 * @param fb
 * @param wateringJob
 * @returns {Promise<void>}
 */
async function waterPlantGroup(fb, wateringJob) {
  console.log(`Now watering: ${wateringJob.plantType}`);
  // Dispatch action to update log state
  boundLogActions.receiveLog({ log: { type: 'info', message: `Now watering: ${wateringJob.plantType}` } });

  const plants = await getPlantGroup(store.getState().dbClient, wateringJob.points);
  console.log('Points: ', plants.points);

  async function loop(n) {
    for (let i = 0; i < n; i++) {
      await moveToPosAtHeight(fb, plants.points[i].x, plants.points[i].y, GROUNDLEVEL + parseInt(wateringJob.height))
        .then(() => waterAtCurrentPos(fb, parseInt(wateringJob.height), parseInt(wateringJob.amount)));
    }
  }

  return await loop(plants.points.length)
    .then(() => Promise.resolve());
}

module.exports = { seedPlantGroup, waterPlantGroup };
const store = require("../redux/store");

const GROUNDLEVEL = -480;
const SAVEHEIGHT = -250;
const SEEDS_Z = -270;
const VACUUMPIN = 9;

/**
 * Taking a connected FarmBot, moving to seeds and picking up one with the vacuum, endposition is at SAVEHEIGHT
 * @param fb
 * @param plantType
 * @returns {Promise<RpcOk | RpcError | RpcOk | RpcError>}
 */
async function collectSeed(fb, plantType) {
    console.log(`Collecting a seed: ${plantType}`);

    return fb.moveAbsolute({ x: store.getState().position.x, y: store.getState().position.y, z: SAVEHEIGHT, speed: 100 })
        .then(() => fb.moveAbsolute({ x: store.getState().position.x, y: 0, z: SAVEHEIGHT, speed: 100 }))
        .then(() => fb.moveAbsolute({ x: store.getState().position.x, y: 0, z: SEEDS_Z, speed: 100 }))
        .then(() => fb.togglePin({ pin_number: VACUUMPIN }))
        .then(() => fb.moveAbsolute({ x: store.getState().position.x, y: 0, z: SAVEHEIGHT, speed: 100 }));
}

/**
 * Taking a connected FarmBot, moving to X and Y position and the depth referring to the GROUNDLEVEL, toggling the vacuum off
 * @param fb
 * @param posX
 * @param posY
 * @param depth
 * @returns {Promise<RpcOk | RpcError | RpcOk | RpcError>}
 */
async function seedAtPos(fb, posX, posY, depth) {
    console.log(`Seeding at (${posX}, ${posY}), depth: ${depth}`);

    return fb.moveAbsolute({ x: store.getState().position.x, y: store.getState().position.y, z: SAVEHEIGHT, speed: 100 })
        .then(() => fb.moveAbsolute({ x: posX, y: posY, z: SAVEHEIGHT, speed: 100 }))
        .then(() => fb.moveAbsolute({ x: posX, y: posY, z: GROUNDLEVEL - depth, speed: 100 }))
        .then(() => fb.togglePin({ pin_number: VACUUMPIN }))
        .then(() => fb.moveAbsolute({ x: posX, y: posY, z: SAVEHEIGHT, speed: 100 }));
}

/**
 * Taking a connected FarmBot and seeding at all positions of the given Seeding Job
 * @param fb
 * @param seedingJob
 * @returns {Promise<void>}
 */
async function seedPlantGroup(fb, seedingJob) {
    console.log(`Now seeding: ${seedingJob.plantType}`);
    console.log('Points: ', seedingJob.points);

    return new Promise(resolve => {
        for (let i = 0, p = Promise.resolve(); i < seedingJob.points.length; i++) {
            p = p.then(() => collectSeed(fb, seedingJob.plantType)
                .then(() => seedAtPos(fb, seedingJob.points[i].x, seedingJob.points[i].y, seedingJob.depth)))
        }
    })
}

module.exports = { seedPlantGroup };

/*
const connectFarmBot = require('./connectFarmBot')
const {exampleSeedingJob} = require("../farmbot-db/farmbotDB");

connectFarmBot().then((fb) => setTimeout((() => {
    console.log('Connected to FB');

    seedPlantGroup(fb, exampleSeedingJob);
}), 10000))
    .catch((err) => console.log("CONNECTION ERROR: ", err))

 */
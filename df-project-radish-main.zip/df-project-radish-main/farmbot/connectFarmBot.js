global.atob = require("atob");
const { boundFarmBotActions } = require("../redux/actions");
const store = require('../redux/store');
const Farmbot = require("farmbot").Farmbot;
const axios = require('axios');

const FAKE_BOT = false;

const connectFarmBot = async () => {
    let body = {
        "user": {
            "email": "kalagdf@rhrk.uni-kl.de",
            "password": "mYfarm2021*"
        }
    };

    if (FAKE_BOT) {
        body = {
            "user": {
                "email": "ramesh@rhrk.uni-kl.de",
                "password": "mYfarm2021*"
            }
        }
    }

    const options = {
        headers: { 'Content-Type': 'application/json' }
    }
    return await axios.post("https://my.farmbot.io/api/tokens", body, options)
        .then((res) => {
            console.log("Token retrieved")
            const token = res.data.token.encoded;
            const fb = new Farmbot({ token });

            return fb.connect().then(() => {
                console.log("FarmBot connected");
                boundFarmBotActions.connect();
                setEventListeners(fb);

                return fb;
            })
                .catch((err) => console.log("Connection error: ", err));
        })
        .catch((err) => console.log("Token error: ", err));
};

const setEventListeners = (fb) => {
    fb.on("offline", () => boundFarmBotActions.disconnect());
    fb.on("online", () => boundFarmBotActions.connect());

    fb.on("status", (status) => {
        const { location_data: { position, axis_states }, pins, informational_settings: { busy, idle } } = status;
        const newState = {
            position,
            axis_states,
            pins,
            busy,
            idle
        };
        const storeState = store.getState();
        const currentState = {
            position: storeState.position,
            axis_states: storeState.axis_states,
            pins: storeState.pins,
            busy: storeState.busy,
            idle: storeState.idle
        };

        if (!deepEqual(currentState, newState)) {
            boundFarmBotActions.receiveStatus({ ...newState, fb });
        }
    });
};

function deepEqual(object1, object2) {
    const keys1 = Object.keys(object1);
    const keys2 = Object.keys(object2);
    if (keys1.length !== keys2.length) {
        return false;
    }
    for (const key of keys1) {
        const val1 = object1[key];
        const val2 = object2[key];
        const areObjects = isObject(val1) && isObject(val2);
        if (
            areObjects && !deepEqual(val1, val2) ||
            !areObjects && val1 !== val2
        ) {
            return false;
        }
    }
    return true;
}

function isObject(object) {
    return object != null && typeof object === 'object';
}

module.exports = connectFarmBot;
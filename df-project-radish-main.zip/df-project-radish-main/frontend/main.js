$(function () {

    //safeDelete();
    clearTab();

    plantGroupSelection();
    plantGroupList();
    plantTypeSelection();

    canvas(); // making a working area
    grid(); // for making the grid in the working area
    drawAllPlants();
    manualRectangle();

    formData(); // for form submission
    seedingTable(); // for showing all the seeding jobs in a table


    wateringFormData();// for watering jobs form submission
    wateringTable();


    statusLog();


});// end $(function(){});


function canvas() {
    // get references to the canvas and context
    var canvas = document.getElementById("canvas");
    var ctx = canvas.getContext("2d");

    // style the context
    ctx.strokeStyle = "yellow";
    ctx.lineWidth = 2;

    // this flag is true when the user is dragging the mouse
    var isDown = false;

    // these vars will hold the starting mouse position
    var startX;
    var startY;
    const canvasW = canvas.getBoundingClientRect().width;
    const canvasH = canvas.getBoundingClientRect().height;

    function handleMouseDown(e) {
        e.preventDefault();
        e.stopPropagation();

        // save the starting x/y of the rectangle
        //startX=parseInt(window.innerWidth-e.clientX);
        //startX=parseInt(canvasW-(e.clientX-offsetX));
        startX = e.offsetX;
        startY = e.offsetY;
        //drawX=parseInt(e.clientX-offsetX);
        //startY=parseInt(e.clientY-offsetY);

        // set a flag indicating the drag has begun
        isDown = true;
    }

    function handleMouseUp(e) {
        e.preventDefault();
        e.stopPropagation();

        // the drag is over, clear the dragging flag
        isDown = false;
    }

    function handleMouseOut(e) {
        e.preventDefault();
        e.stopPropagation();

        // the drag is over, clear the dragging flag
        isDown = false;
    }

    function handleMouseMove(e) {
        e.preventDefault();
        e.stopPropagation();

        // if we're not dragging, just return
        if (!isDown) {
            return;
        }

        // get the current mouse position
        var endX = e.offsetX;
        var endY = e.offsetY;

        // Put your mousemove stuff here

        // clear the canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // calculate the rectangle width/height based
        // on starting vs current mouse position
        var width = endX - startX;
        var height = endY - startY;
        var tw = Math.abs(width);
        var th = Math.abs(height);

        // draw a new rect from the start position
        // to the current mouse position
        ctx.strokeRect(startX, startY, width, height);

        /*document.getElementById("tooltip").innerHTML = "<label> H:" + th + "</label><br/><label> W:" + tw + "</label>";
        $("#tooltip").css({ position: "absolute", left: e.x + 15, top: e.y - 80 });*/

        document.getElementById("x1").value = canvasW - startX;
        document.getElementById("y1").value = startY;
        document.getElementById("x2").value = canvasW - endX;
        document.getElementById("y2").value = endY;

    }

    // listen for mouse events
    canvas.addEventListener("mousedown", handleMouseDown);
    canvas.addEventListener("mouseup", handleMouseUp);
    canvas.addEventListener("mouseout", handleMouseOut);
    canvas.addEventListener("mousemove", handleMouseMove);
} // This is for drawing in the canvas

function manualRectangle() {
    var canvas = document.getElementById("canvas");

    var sx = document.getElementById("x1");
    var sy = document.getElementById("y1");
    var ex = document.getElementById("x2");
    var ey = document.getElementById("y2");
    var width, height;

    sx.addEventListener("keyup", function () {
        sx = canvas.width - this.value;
        width = ex - sx;
        height = ey - sy;
        manualRectangleDraw(sx, sy, width, height);
    }, false);

    sy.addEventListener("keyup", function () {
        sy = this.value;
        width = ex - sx;
        height = ey - sy;
        manualRectangleDraw(sx, sy, width, height);
    }, false);

    ex.addEventListener("keyup", function () {
        ex = canvas.width - this.value;
        width = ex - sx;
        height = ey - sy;
        manualRectangleDraw(sx, sy, width, height);
    }, false);

    ey.addEventListener("keyup", function () {
        ey = this.value;
        width = ex - sx;
        height = ey - sy;
        manualRectangleDraw(sx, sy, width, height);
    }, false);
} // This is for Manual input of drawing the working area rectangle
function manualRectangleDraw(sx, sy, width, height) {
    var canvas = document.getElementById("canvas");
    var ctx = canvas.getContext("2d");

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.strokeRect(sx, sy, width, height);

} // This is for Drawing the rectangle by using manual input

function grid() {
    var canvas = document.getElementById('canvasGrid');
    var ctx = canvas.getContext("2d");

    for (var i = 0; i <= 1200; i = i + 10) {
        //vertical line
        ctx.moveTo(i, 0);
        ctx.lineTo(i, 1200);

        //horizontal line
        ctx.moveTo(0, i);
        ctx.lineTo(1200, i);

        ctx.strokeStyle = "#c09655";
        ctx.stroke();
    }

    ctx.beginPath();
    ctx.font = "bold 12px arial";
    ctx.fillStyle = "#4f2b14";
    let count = 1200;
    for (var i = 0; i <= 1200; i = i + 100) {
        //horizontal line
        ctx.moveTo(i, 0);
        ctx.lineTo(i, 1200);
        ctx.fillText(count, i, 12);
        ctx.fillText(count, i, 848);

        //vertical line
        ctx.moveTo(0, i);
        ctx.lineTo(1200, i);
        ctx.fillText(i, 0, i);
        ctx.fillText(i, 1180, i);
        count -= 100;


        ctx.strokeStyle = "#4f2b14";
        ctx.stroke();
    }

} // This is for the canvas grid drawing
function drawPlants(pointsId) {

    fetch(`http://localhost:3000/plant-groups/${pointsId}`)
        .then(response => {
            return response.json();
        })
        .then(data => {
                console.log(data);

                let canvas = document.getElementById("canvasGrid");
                let ctx = canvas.getContext("2d");

                const canvasW = canvas.getBoundingClientRect().width;
                const canvasH = canvas.getBoundingClientRect().height;

                if (data.plantType === 'Radish') {
                    let base_image_ = new Image();
                    base_image_.src = 'https://cdn-icons-png.flaticon.com/512/186/186130.png';
                    base_image_.onload = function () {
                        for (let point of data.points) {
                            let x = canvasW - point.x;
                            ctx.drawImage(base_image_, x - 15, point.y - 30, 30, 30);
                            console.log(point.x, point.y);
                        }
                    }
                }
                if (data.plantType === 'Lettuce') {
                    let base_image_ = new Image();
                    base_image_.src = 'https://cdn-icons-png.flaticon.com/512/1155/1155257.png';
                    base_image_.onload = function () {
                        for (let point of data.points) {
                            let x = canvasW - point.x;
                            ctx.drawImage(base_image_, x - 15, point.y - 30, 30, 30);
                            console.log(point.x, point.y);
                        }
                    }
                }
            }
        );


    /* axios.get(`/plant-groups/${pointsId}`)
         .then(res => {
             console.log(res);
             console.log(res.data);


             let canvas = document.getElementById("canvasGrid");
             let ctx = canvas.getContext("2d");

             const canvasW = canvas.getBoundingClientRect().width;
             const canvasH = canvas.getBoundingClientRect().height;

             if (data.plantType === 'Radish') {
                 let base_image_ = new Image();
                 base_image_.src = 'https://cdn-icons-png.flaticon.com/512/186/186130.png';
                 base_image_.onload = function () {
                     for (let point of data.points) {
                         let x= canvasW-point.x;
                         ctx.drawImage(base_image_, x - 15, point.y - 30, 30, 30);
                         console.log(point.x, point.y);
                     }
                 }
             }
             if (data.plantType === 'Lettuce') {
                 let base_image_ = new Image();
                 base_image_.src = 'https://cdn-icons-png.flaticon.com/512/1155/1155257.png';
                 base_image_.onload = function () {
                     for (let point of data.points) {
                         let x= canvasW-point.x;
                         ctx.drawImage(base_image_, x - 15, point.y - 30, 30, 30);
                         console.log(point.x, point.y);
                     }
                 }
             }


             /!*if (data.plantType === 'Radish') {
                 let base_image_ = new Image();
                 base_image_.src = 'https://cdn-icons-png.flaticon.com/512/186/186130.png';
                 base_image_.onload = function () {
                     for (let point of object.points) {
                         let x= canvasW-point.x;
                         ctx.drawImage(base_image_, x - 15, point.y - 30, 30, 30);
                         console.log(point.x, point.y);
                     }
                 }
             }
             if (object.plantType === 'Lettuce') {
                 let base_image_ = new Image();
                 base_image_.src = 'https://cdn-icons-png.flaticon.com/512/1155/1155257.png';
                 base_image_.onload = function () {
                     for (let point of object.points) {
                         let x= canvasW-point.x;
                         ctx.drawImage(base_image_, x - 15, point.y - 30, 30, 30);
                         console.log(point.x, point.y);
                     }
                 }
             }*!/
         })*/
} // This is for drawing the plants after pressing the Start Seeding Button
function drawAllPlants() {

    fetch("http://localhost:3000/plant-groups")
        .then(response => {
            return response.json();
        })
        .then(data => {
                console.log(data);

                let canvas = document.getElementById("canvasGrid");
                let ctx = canvas.getContext("2d");

                const canvasW = canvas.getBoundingClientRect().width;
                //const canvasH = canvas.getBoundingClientRect().height;

                for (let i = 0; i < data.length; i++) {
                    for (let j = 0; j < data[i].points.length; j++) {
                        if (data[i].plantType === 'Radish' && data[i].planted === true) {
                            let points = data[i].points[j];
                            let base_image_ = new Image();
                            base_image_.src = 'https://cdn-icons-png.flaticon.com/512/186/186130.png';
                            base_image_.onload = function () {
                                let x = canvasW - points.x;
                                ctx.drawImage(base_image_, x - 15, points.y - 30, 30, 30);
                            }
                        }
                        if (data[i].plantType === 'Lettuce' && data[i].planted === true) {
                            let points = data[i].points[j];
                            let base_image_ = new Image();
                            base_image_.src = 'https://cdn-icons-png.flaticon.com/512/1155/1155257.png';
                            base_image_.onload = function () {
                                let x = canvasW - points.x;
                                ctx.drawImage(base_image_, x - 15, points.y - 30, 30, 30);
                            }
                        }

                    }

                }

            }
        );
} // This is for drawing all the plants on window load
function drawSelectedPlants(pointsId) {
    fetch(`http://localhost:3000/plant-groups/${pointsId}`)
        .then(response => {
            return response.json();
        })
        .then(data => {
                console.log(data);

                let canvas = document.getElementById("canvas");
                let ctx = canvas.getContext("2d");

                const canvasW = canvas.getBoundingClientRect().width;

                if (data.plantType === 'Radish') {
                    for (let point of data.points) {
                        let x = canvasW - point.x;
                        ctx.beginPath();
                        ctx.arc(x, point.y - 15, 20, 0, 2 * Math.PI);
                        ctx.stroke();
                    }
                }
                if (data.plantType === 'Lettuce') {
                    for (let point of data.points) {
                        let x = canvasW - point.x;
                        ctx.beginPath();
                        ctx.arc(x, point.y - 15, 20, 0, 2 * Math.PI);
                        ctx.stroke();
                    }
                }
            }
        );
} // This is for drawing a circle over the plants of selected plant groups


//All Watering Functions
function wateringFormData() {

    let today = new Date().toISOString().substring(0,10);
    let now = new Date().toISOString().substring(11,16);
    console.log(now);
    document.querySelector("#date").value = today;
    document.querySelector("#time").value = "12:00";
    // this part is for taking the data from the form and store it as pair value
    document.getElementById("wateringForm").addEventListener('submit', (e) => {
        e.preventDefault();


        const formData = new FormData(e.target);
        const data = Array.from(formData.entries()).reduce((memo, [key, value]) => ({
            ...memo,
            [key]: value,
        }), {});

        //document.getElementById('output').innerHTML = JSON.stringify(data);
        // till this part is for taking the data from the form and store it as pair value

        if (validateWateringForm()) {
            console.log(data);

            data.hours = data.hours * 60;
            console.log(data.hours);

            axios.post('http://localhost:3000/jobs/watering', data)
                .then(function (response) {
                    console.log(response.status);
                    console.log(data);
                    alert("Watering Job Created Successfully");
                })
                .catch(function (error) {
                    console.log(error);
                    alert("No watering job created. Watering job parameters need to be adjusted!");
                });

            wateringTable();
        } else {
            //alert("Seeding Job does not Created Successfully");
            wateringTable();
        }

    });
} // This is for watering form submission
function validateWateringForm() {
    let name = document.forms["wateringForm"]["name"].value;
    let plantType = document.forms["wateringForm"]["plantType"].value;
    let plantGroup = document.forms["wateringForm"]["points"].value;
    let height = document.forms["wateringForm"]["height"].value;
    let amount = document.forms["wateringForm"]["amount"].value;
    let time = document.forms["wateringForm"]["time"].value;
    let date = document.forms["wateringForm"]["date"].value;
    let hours = document.forms["wateringForm"]["hours"].value;

    if (name === "") {
        alert("Name must be filled");
        return false;
    } else if (plantType === "") {
        alert("Plant Type must be filled");
        return false;
    } else if (plantGroup === "") {
        alert("plant Group must be filled");
        return false;
    } else if (height === "") {
        alert("Height Depth must be filled");
        return false;
    } else if (amount === "") {
        alert("Watering amount must be filled");
        return false;
    } else if (time === "") {
        alert("Time must be filled");
        return false;
    } else if (date === "") {
        alert("Date must be filled");
        return false;
    } else if (hours === "") {
        alert("Watering Interval must be filled");
        return false;
    } else {
        console.log("Form Validated");
        wateringTable();
        return true;
    }
} // This is for watering form validation
function wateringTable() {
    fetch("http://localhost:3000/jobs/watering")
        .then(response => {
            return response.json();
        })
        .then(data => {
                var trHTML = '';
                const objects = data.reverse();
                console.log(objects);

                for (let object of objects) {
                    trHTML += '<tr>';
                    trHTML += `<td class="tdhover" onclick="wateringRowClick('${encodeURIComponent(JSON.stringify(object))}')">` + object['name'] + `</td>`;
                    trHTML += '<td class="tdhover">' + object['plantType'] + '</td>';
                    trHTML += '<td class="tdhover">' + object['height'] + '</td>';
                    trHTML += '<td class="tdhover">' + object['amount'] + '</td>';
                    /*trHTML += '<td>' + object['totalAmount'] + '</td>';*/
                    trHTML += '<td class="tdhover">' + object['time'] + '</td>';
                    trHTML += '<td class="tdhover">' + object['date'] + '</td>';
                    trHTML += '<td class="tdhover">' + object['hours'] / 60 + '</td>';
                    if (object['active'] === "true") {
                        /*trHTML += `<td><button type="button" id="activeToggleButton" class="activeToggleButton" onclick= "wateringToggle('${encodeURIComponent(JSON.stringify(object))}')">Active</button></td>`;*/
                        trHTML += `<td><label class="switch"><input type="checkbox" checked onclick= "wateringToggle('${encodeURIComponent(JSON.stringify(object))}')"><span class="slider"></span></label></td>`;
                    } else {
                        /*trHTML += `<td><button type="button" id="deactiveToggleButton" class="deactiveToggleButton" onclick= "wateringToggle('${encodeURIComponent(JSON.stringify(object))}')">Deactive</button></td>`;*/
                        trHTML += `<td><label class="switch"><input type="checkbox" onclick= "wateringToggle('${encodeURIComponent(JSON.stringify(object))}')"><span class="slider"></span></label></td>`;
                    }

                    //trHTML += '<td><button type="button" onclick= "editSeeding(\'' + object['_id'] + '\')">Edit</button></td>';
                    //trHTML += '<td><button type="button" class="deleteButton" onclick="deleteWatering(\'' + object['_id'] + '\')">Del</button></td>';
                    trHTML += `<td><button type="button" onclick="startWatering('${encodeURIComponent(JSON.stringify(object))}')">Water Now</button></td>`;
                    trHTML += '<td><i class="fa fa-trash-o" style="font-size:30px;color: red" onclick="deleteWatering(\'' + object['_id'] + '\')"></i></td>';
                    trHTML += "</tr>";
                }
                console.log(trHTML);
                document.getElementById("myWateringTable").innerHTML = trHTML;


            }
        );
    // Till this part Fetching data from the database and populating the table
} // This is for showing the watering table with data from the database
function wateringToggle(obj) {
    let object = JSON.parse(decodeURIComponent(obj));
    console.log(object);
    console.log(JSON.parse(JSON.stringify(object)));

    if (object.active === "true") {
        object.active = "false";
        console.log(object);
        axios.post(`http://localhost:3000/jobs/watering/${object._id}`, object)
            .then(function (response) {
                console.log(response.status);
            })
            .catch(function (error) {
                console.log(error);
            });
    } else {
        object.active = "true";
        console.log(object);
        axios.post(`http://localhost:3000/jobs/watering/${object._id}`, object)
            .then(function (response) {
                console.log(response.status);
            })
            .catch(function (error) {
                console.log(error);
            });
    }
    setTimeout(wateringTable, 1000);
} // This is for toggling button in the watering table

function plantTypeSelection() {
    let selectedPlantType = document.getElementById("wplantType");
    console.log(document.getElementById("wplantType"));
    selectedPlantType.onchange = function () {
        plantGroupList();
    }
} // This is for plant type selection in the watering form
function plantGroupSelection() {
    let selectedPlantGroup = document.getElementById("points");
    console.log(document.getElementById("points"));
    selectedPlantGroup.onchange = function () {
        var canvas = document.getElementById("canvas");
        var ctx = canvas.getContext("2d");
        ctx.clearRect(0, 0, 1200, 850);

        drawSelectedPlants(document.getElementById("points").value);
        var pid = document.getElementById("points").value;

        fetch(`http://localhost:3000/plant-groups/${pid}`)
            .then(response => {
                return response.json();
            })
            .then(data => {
                document.getElementById("wplantType").value = data.plantType;

            });
    }
} // This is for the plant group selection for sending data to draw all the selected group's plants
function plantGroupList() {
    let dropdown = document.getElementById("points");
    dropdown.length = 0;

    /*    let defaultOption = document.createElement('option');
        defaultOption.text = '---';

        dropdown.add(defaultOption);
        dropdown.selectedIndex = 0;*/

    fetch("http://localhost:3000/plant-groups")
        .then(
            function (response) {
                if (response.status !== 200) {
                    console.warn('Looks like there was a problem. Status Code: ' +
                        response.status);
                    return;
                }

                // Examine the text in the response
                response.json().then(function (data) {
                    let option;
                    console.log(data);

                    for (let i = 0; i < data.length; i++) {
                        if (document.getElementById("wplantType").value === "all" && data[i].planted === true) {
                            option = document.createElement('option');
                            option.text = data[i].name;
                            option.value = data[i]._id;
                            dropdown.add(option);
                        } else {
                            if (document.getElementById("wplantType").value === data[i].plantType && data[i].planted === true) {
                                option = document.createElement('option');
                                option.text = data[i].name;
                                option.value = data[i]._id;
                                dropdown.add(option);
                            }
                        }
                    }
                });
            }
        )
        .catch(function (err) {
            console.error('Fetch Error -', err);
        });
} // This is for getting all the plant group list according to the selected plant type

function wateringRowClick(obj) {
    let object = JSON.parse(decodeURIComponent(obj));
    console.log(object._id);

    showPlants(object.points);
    wateringJobDetails(object);
} // This is for showing all the seeding plants and all the details job after clicking on a row

function wateringJobDetails(object) {

    // Get the modal
    var modal = document.getElementById("details");
    modal.style.display = "block";

    document.getElementById("modalHeader").innerHTML = object.name;

// Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];


// When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
    }

// When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    }

    const list = document.getElementById("list");
    list.innerHTML = "";
    const plantType = document.createElement("li");
    plantType.innerHTML = "Plant Type: " + object.plantType;
    const wateramount = document.createElement("li");
    wateramount.innerHTML = "Water Amount: " + object.amount;
    const height = document.createElement("li");
    height.innerHTML = "Watering Height: " + object.height;
    const stime = document.createElement("li");
    stime.innerHTML = "Starting Time: " + object.time;
    const sdate = document.createElement("li");
    sdate.innerHTML = "Starting Date: " + object.date;
    const interval = document.createElement("li");
    interval.innerHTML = "Watering Interval: " + object.hours / 60 + " H";
    const points = document.createElement("li");


    list.appendChild(plantType);
    list.appendChild(sdate);
    list.appendChild(stime);
    list.appendChild(wateramount);
    list.appendChild(height);
    list.appendChild(interval);

    fetch(`http://localhost:3000/plant-groups/${object.points}`)
        .then(response => {
            return response.json();
        })
        .then(data => {
            console.log(data.points.length);
            points.innerHTML = "Number of Plants: " + data.points.length;
            list.appendChild(points);
        });

    /*setTimeout(jobDetails, 5000);*/


    if (object.plantType === "Radish") {
        document.getElementById("modal-img").src = 'https://cdn-icons-png.flaticon.com/512/186/186130.png';
    }
    if (object.plantType === "Lettuce") {
        document.getElementById("modal-img").src = 'https://cdn-icons-png.flaticon.com/512/1155/1155257.png';
    }


} // This is for showing the detailed information of a selected row from the seeding table

function startWatering(obj) {
    let object = JSON.parse(decodeURIComponent(obj));
    console.log(object._id);
    drawPlants(object.points);
    axios.get(`/jobs/watering/${object['_id']}`)
        .then(res => {
            console.log(res);
            console.log(res.data);
        })
} // This is for start watering job now
function deleteWatering(id) {

    console.log(id);
    var deleteConfirmed = confirm("Are you sure?");
    if (deleteConfirmed) {
        axios.delete(`/jobs/watering/${id}`)
            .then(res => {
                console.log(res);
                console.log(res.data);
                wateringTable();
            })
    }
} // This is for delete watering job with a specific id


//All Seeding Functions
function seedingTable() {
    fetch("http://localhost:3000/jobs/seeding")
        .then(response => {
            return response.json();
        })
        .then(data => {
                var trHTML = '';
                const objects = data.reverse();
                console.log(objects);
                let flag = true;

                for (let object of objects) {
                    trHTML += '<tr>';
                    trHTML += `<td class="tdhover" onclick="seedingRowClick('${encodeURIComponent(JSON.stringify(object))}')">` + object['name'] + `</td>`;
                    trHTML += '<td class="tdhover">' + object['plantType'] + '</td>';
                    trHTML += '<td class="tdhover">' + object['density'] + '</td>';
                    trHTML += '<td class="tdhover">' + object['depth'] + '</td>';
                    /*trHTML += '<td><label id="switch" class="switch"> <input onclick="toggle(\'' + object['plantType'] + '\')" id="checkbox" class="checkbox" type="checkbox"> <span class="slider"></span> </label></td>';*/
                    //trHTML += '<td><button type="button" onclick= "showPlants(\'' + object['points'] + '\')">Plants</button></td>';
                    trHTML += `<td><button type="button" onclick="startSeeding('${encodeURIComponent(JSON.stringify(object))}')">Start Seeding</button></td>`;
                    trHTML += '<td><i class="fa fa-trash-o" style="font-size:30px;color: red" onclick="deleteSeeding(\'' + object['_id'] + '\')"></i></td>';
                    trHTML += "</tr>";
                }
                console.log(trHTML);
                document.getElementById("mytable").innerHTML = trHTML;


            }
        );
    // Till this part Fetching data from the database and populating the table
} // This is for showing the seeding table with data from the database
function formData() {
    // this part is for taking the data from the form and store it as pair value
    document.getElementById("myForm").addEventListener('submit', (e) => {
        e.preventDefault();


        const formData = new FormData(e.target);
        const data = Array.from(formData.entries()).reduce((memo, [key, value]) => ({
            ...memo,
            [key]: value,
        }), {});

        //document.getElementById('output').innerHTML = JSON.stringify(data);
        // till this part is for taking the data from the form and store it as pair value

        if (validateForm()) {
            console.log(data);
            postRequest(data);
            seedingTable();
        } else {
            //alert("Seeding Job does not Created Successfully");
            seedingTable();
        }

    });
} // This is for seeding form submission
function validateForm() {
    let name = document.forms["myForm"]["name"].value;
    let planttype = document.forms["myForm"]["plantType"].value;
    let density = document.forms["myForm"]["density"].value;
    let depth = document.forms["myForm"]["depth"].value;
    let x1 = document.forms["myForm"]["x1"].value;
    let x2 = document.forms["myForm"]["x2"].value;
    let y1 = document.forms["myForm"]["y1"].value;
    let y2 = document.forms["myForm"]["y2"].value;
    //let message= "";

    if (name == "") {
        alert("Fill out all fields");
        return false;
    }
    if (name === "") {
        alert("Name must be filled");
        return false;
    } else if (planttype === "") {
        alert("Plant Type must be filled");
        return false;
    } else if (density === "") {
        alert("Density must be filled");
        return false;
    } else if (depth === "") {
        alert("Seeding Depth must be filled");
        return false;
    } else if (x1 === "") {
        alert("x1 must be filled");
        return false;
    } else if (x2 === "") {
        alert("x2 must be filled");
        return false;
    } else if (y1 === "") {
        alert("y1 must be filled");
        return false;
    } else if (y2 === "") {
        alert("y2 must be filled");
        return false;
    } else {
        console.log("Form Validated");
        seedingTable();
        return true;
    }
} // This is for seeding form validation

function postRequest(data) {
    // this part is for sending the data from the html to backend
    axios.post('http://localhost:3000/jobs/seeding', data)
        .then(function (response) {
            console.log(response.status);
            console.log(data);
            alert("Seeding Job Created Successfully");
        })
        .catch(function (error) {
            console.log(error);
            alert("No seeding points created. Seeding job parameters need to be adjusted!");
        });
    // till this part is for sending the data from the html to backend
} // This is for posting request to the database with all the validated form data
function editSeeding(id) {
    console.log(id);
    axios.get('/jobs')
        .then(res => {
            console.log(res);
            console.log(res.data);

            //document.getElementById('name').innerHTML = res.data.name.value;
        })
} // This is for editing seeding jobs
function deleteSeeding(id) {
    console.log(id);
    var deleteConfirmed = confirm("Are you sure?");
    if (deleteConfirmed) {
        axios.delete(`/jobs/seeding/${id}`)
            .then(res => {
                console.log(res);
                console.log(res.data);
                seedingTable();
            })
    }

} // This is for delete seeding job with specific id
function startSeeding(obj) {
    let object = JSON.parse(decodeURIComponent(obj));
    console.log(object._id);
    console.log(object.points);
    drawPlants(object.points);
    axios.get(`/jobs/seeding/${object['_id']}`)
        .then(res => {
            console.log(res);
            console.log(res.data);
        })
} // This is for starting a seeding job now
function seedingRowClick(obj) {
    let object = JSON.parse(decodeURIComponent(obj));
    console.log(object._id);

    showPlants(object.points);
    seedingJobDetails(object);
} // This is for showing all the seeding plants and all the details job after clicking on a row

function seedingJobDetails(object) {

    // Get the modal
    var modal = document.getElementById("details");
    modal.style.display = "block";

    document.getElementById("modalHeader").innerHTML = object.name;

// Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];


// When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
    }

// When the user clicks anywhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    }

    const list = document.getElementById("list");
    list.innerHTML = "";
    const plantType = document.createElement("li");
    plantType.innerHTML = "Plant Type: " + object.plantType;
    const density = document.createElement("li");
    density.innerHTML = "Density: " + object.density;
    const depth = document.createElement("li");
    depth.innerHTML = "Depth: " + object.depth;
    const points = document.createElement("li");


    list.appendChild(plantType);
    list.appendChild(density);
    list.appendChild(depth);

    fetch(`http://localhost:3000/plant-groups/${object.points}`)
        .then(response => {
            return response.json();
        })
        .then(data => {
            console.log(data.points.length);
            points.innerHTML = "Number of Plants: " + data.points.length;
            list.appendChild(points);
        });

    /*setTimeout(jobDetails, 5000);*/


    if (object.plantType === "Radish") {
        document.getElementById("modal-img").src = 'https://cdn-icons-png.flaticon.com/512/186/186130.png';
    }
    if (object.plantType === "Lettuce") {
        document.getElementById("modal-img").src = 'https://cdn-icons-png.flaticon.com/512/1155/1155257.png';
    }


} // This is for showing the detailed information of a selected row from the seeding table
function showPlants(pointsId) {
    var canvas = document.getElementById("canvas");
    var ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, 1200, 850);
    drawSelectedPlants(pointsId);
} // This is for showing the plants of a selected row from the seeding table


function clearTab() {
    var tabcontent = document.getElementsByClassName("tabcontent");
    for (var i = 1; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
} // This is for clearing the tab content
function openTab(cityName) {
    var i, tablinks;
    var tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    /* evt.currentTarget.className += " active";*/
} // This is for showing the tab contents

var lastStatusMessage = "";

function statusLog(message) {
    if (message) {
        document.getElementById("latestStatus").innerHTML = message;
    }
    if (message !== lastStatusMessage) {
        lastStatusMessage = message;
        statusLogList(message);
    }
} // This is for showing the status log on bottom of the screen
function statusLogList(message) {
    if (message) {
        var list = document.getElementById("myList");

        const node = document.createElement("li");
        const textnode = document.createTextNode(message);
        node.appendChild(textnode);
        document.getElementById("statusBox").appendChild(node);
    }
}
function statusToggle() {
    var text = document.getElementById("button");
    if (text.innerHTML === "+") {
        text.innerHTML = "-";
        $("#statusBox").show(100);
    } else {
        text.innerHTML = "+";
        $("#statusBox").hide(100);
    }
}

function safeDelete() {
    axios.delete(`/jobs/watering`)
        .then(res => {
            console.log(res);
            console.log(res.data);
            wateringTable();
        })
} // This is for safe deletion

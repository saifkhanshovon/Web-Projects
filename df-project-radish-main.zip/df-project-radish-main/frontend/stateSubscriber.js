$(function () {
    subscribeToStatus();
});

function setStatus(newStatus) {
    const status = newStatus.busy ? "Busy" : "Idle";
    document.getElementById("connection").innerHTML = status;
}

function setLogs(newLog) {
    // Log is an object like { type: 'info', message: 'Seeding' }
    console.log("NEW LOG: ", newLog.message);
    statusLog(newLog.message);
}

function subscribeToStatus() {
    const status = new EventSource('http://localhost:3000/status');

    status.onmessage = (event) => {
        const parsedData = JSON.parse(event.data);
        console.log("RECEIVED STATE: ", JSON.stringify(parsedData));
        setStatus(parsedData);
        setLogs(parsedData.log);
    };
}
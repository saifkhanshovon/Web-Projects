const mongodb = require("mongodb");


async function addPlantGroup(client, newPlantGroup) {
    const result = await client.db("farmbot").collection("plantGroups").insertOne(newPlantGroup);
    console.log(`New plant group created with the following id: ${result.insertedId}`);
    return result.insertedId;
}

async function getAllPlantGroups(client) {
    const cursor = await client.db("farmbot").collection("plantGroups").find();
    const results = await cursor.toArray();

    if (results.length > 0) {
        console.log(`Found plant group(s):`);
        results.forEach((result, i) => {
            console.log(`${i + 1}. name: ${result.name}`);
            console.log(`   _id: ${result._id}`);
            console.log(`content: ${result}`);
        });
        return results;
    } else {
        console.log(`No plant groups found`);
        return [];
    }
}

async function getPlantGroup(client, id) {
    const result = await client.db("farmbot").collection("plantGroups").findOne({ _id: mongodb.ObjectId(id.toString()) });

    if (result) {
        console.log(`Found a plant group with the id: ${id}`);
        return result;
    } else {
        console.log(`No plant group found with the id: ${id}`);
        return null;
    }
}

async function removePlantGroup(client, id) {
    const result = await client.db("farmbot").collection("plantGroups").findOne({ _id: mongodb.ObjectId(id.toString()) });
    if (result) {
        console.log(`Found a plant group with the id: ${id}`);
        res = await client.db("farmbot").collection("seedingJobs").deleteOne(result);
        console.log(res);
    } else {
        console.log(`No plant group found with the id: ${id}`);
    }
}

async function removeAllPlantGroups(client) {
    const result = await client.db("farmbot").collection("plantGroups").deleteMany({});

    console.log(`${result.deletedCount} plant groups deleted from farmbot database`);
}

async function changePlantGroupPlantedState(client, id, planted) {
    const res = await client.db("farmbot").collection("plantGroups").updateOne(
      { _id: mongodb.ObjectId(id.toString()) },
      { $set: { planted: planted } });

    if (res.acknowledged) {
        console.log('Updated plant-group: ', id);

        return res;
    } else {
        console.log(`No plant-group updated`);
        return null;
    }
}

module.exports = { addPlantGroup, getAllPlantGroups, getPlantGroup, removePlantGroup, removeAllPlantGroups, changePlantGroupPlantedState }
const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;

const uri = 'mongodb://localhost/farmbot';
const client = new MongoClient(uri);

async function connect() {
    console.log(`Trying to connect to ${uri}`)

    try {
        await client.connect();

        console.log('Connection successful.');
        return client;

    } catch (e) {
        console.log('Failed to connect.', e.message);
    }
}

async function addSeedingJob(client, newSeedingJob) {
    const result = await client.db("farmbot").collection("seedingJobs").insertOne(newSeedingJob);
    console.log(`New seeding job created with the following id: ${result.insertedId}`);
    return result.insertedId;
}

async function getAllSeedingJobs(client) {
    const cursor = await client.db("farmbot").collection("seedingJobs").find();
    const results = await cursor.toArray();

    if (results.length > 0) {
        console.log(`Found seeding job(s):`);
        results.forEach((result, i) => {
            console.log(`${i + 1}. name: ${result.name}`);
            console.log(`   _id: ${result._id}`);
            console.log(`content: ${result}`);
        });
        return results;
    } else {
        console.log(`No seeding jobs found`);
        return [];
    }
}

async function getSeedingJob(client, id) {
    const result = await client.db("farmbot").collection("seedingJobs").findOne({ _id: mongodb.ObjectId(id.toString()) });

    if (result) {
        console.log('Found seeding job: ', result.id);
        return result;
    } else {
        console.log(`No seeding job found`);
        return null;
    }
}

async function removeSeedingJob(client, id) {
    const result = await client.db("farmbot").collection("seedingJobs").findOne({ _id: mongodb.ObjectId(id.toString()) });
    if (result) {
        console.log(`Found a Seeding Job with the id: ${id}`);
        res = await client.db("farmbot").collection("seedingJobs").deleteOne(result);
        console.log(res);
    } else {
        console.log(`No Seeding Job found with the id: ${id}`);
    }
}

async function removeAllSeedingJobs(client) {
    const result = await client.db("farmbot").collection("seedingJobs").deleteMany({});

    console.log(`${result.deletedCount} Seeding Jobs deleted from farmbot database`);
}

module.exports = { connect, addSeedingJob, getSeedingJob, getAllSeedingJobs, removeSeedingJob, removeAllSeedingJobs };

/* Example seeding job
const exampleSeedingJob = {
   "name":"Radish_2x2_field2",
   "plantType":"Radish",
   "density":0.2,
   "depth":10,
   "points":[
      {
         "x":300,
         "y":100
      },
      {
         "x":400,
         "y":200
      },
      {
         "x":300,
         "y":200
      },
      {
         "x":400,
         "y":100
      },
      {
         "x":350,
         "y":100
      },
      {
         "x":350,
         "y":200
      },
      {
         "x":300,
         "y":150
      },
      {
         "x":350,
         "y":150
      },
      {
         "x":400,
         "y":150
      }
   ],
   "workingArea":{
      "start":{
         "x":300,
         "y":100
      },
      "end":{
         "x":400,
         "y":200
      }
   }
};
 */


/* Add example seeding job to DB
connect().then(r =>
    addSeedingJob(client, exampleSeedingJob
        ).then(r =>
            client.close()
        )
);
 */

/* Get and print all seeding jobs from DB
connect().then(r =>
    getAllSeedingJobs(client).then(r =>
        client.close().then(p => {
            console.log(r);

            var json = JSON.stringify(r, null, 4);
            var fs = require('fs');
            fs.writeFile('exampleSeedingJobs.json', json, 'utf8', function(err) {
                if (err) throw err;
                console.log('complete');
            });
        })
    )
);
 */

/* Remove specific seeding job with the name Radish
connect().then(r =>
    removeSeedingJob(client, "Radish"
    ).then(r =>
        client.close()
    )
);
 */

/*  Remove all seeding jobs
connect().then(r =>
    removeAllSeedingJobs(client, "Radish"
    ).then(r =>
        client.close()
    )
);
 */

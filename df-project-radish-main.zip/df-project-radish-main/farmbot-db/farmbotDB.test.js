const connect = require("./connectFarmBotDB");
const { addSeedingJob, getSeedingJob, getAllSeedingJobs, removeSeedingJob, removeAllSeedingJobs } = require("./seedingJob");

/* Example seeding job */
const exampleSeedingJob = {
   "name":"Radish_2x2_field2",
   "plantType":"Radish",
   "density":0.2,
   "depth":10,
   "points":[
      {
         "x":300,
         "y":100
      },
      {
         "x":400,
         "y":200
      },
      {
         "x":300,
         "y":200
      },
      {
         "x":400,
         "y":100
      },
      {
         "x":350,
         "y":100
      },
      {
         "x":350,
         "y":200
      },
      {
         "x":300,
         "y":150
      },
      {
         "x":350,
         "y":150
      },
      {
         "x":400,
         "y":150
      }
   ],
   "workingArea":{
      "start":{
         "x":300,
         "y":100
      },
      "end":{
         "x":400,
         "y":200
      }
   }
};


/* Add example seeding job to DB
connect().then(r =>
    addSeedingJob(client, exampleSeedingJob
        ).then(r =>
            client.close()
        )
);
 */

/* Get and print all seeding jobs from DB
connect().then(r =>
    getAllSeedingJobs(client).then(r =>
        client.close().then(p => {
            console.log(r);

            var json = JSON.stringify(r, null, 4);
            var fs = require('fs');
            fs.writeFile('exampleSeedingJobs.json', json, 'utf8', function(err) {
                if (err) throw err;
                console.log('complete');
            });
        })
    )
);
 */

/* Remove specific seeding job with the name Radish
connect().then(r =>
    removeSeedingJob(client, "Radish"
    ).then(r =>
        client.close()
    )
);
 */

/*  Remove all seeding jobs
connect().then(r =>
    removeAllSeedingJobs(client, "Radish"
    ).then(r =>
        client.close()
    )
);
 */

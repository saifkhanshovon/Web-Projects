# farmbot database

Deploying a local instance of mongodb.
Uses a database 'farmbot'. E.g. seeding jobs are stored in the collection 'seedingJobs'.

Structure of a seeding job:
```javascript
const exampleSeedingJob = {
    "name":"Radish_2x2",
    "plantType":"Radish",
    "density":0.1,
    "depth":6,
    "points":[
        {
            "x":100,
            "y":100
        },
        {
            "x":200,
            "y":200
        },
        {
            "x":100,
            "y":200
        },
        {
            "x":200,
            "y":100
        }
    ],
    "workingArea":{
        "start":{
            "x":100,
            "y":100
        },
        "end":{
            "x":200,
            "y":200
        }
    }
};
```


It is possible to:
* insert single seeding jobs
* retrieve all seeding jobs
* delete a single seeding job by name
* delete all seeding jobs
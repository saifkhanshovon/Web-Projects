const mongodb = require('mongodb');
const { addPlantGroup, getAllPlantGroups, getPlantGroup, removePlantGroup, removeAllPlantGroups } = require("../farmbot-db/plantGroup")

async function addSeedingJob(client, newSeedingJob) {
    if (Array.isArray(newSeedingJob.points)) {
        const { name, points, plantType } = newSeedingJob;
        const pointsID = await addPlantGroup(client, { name: name + " Plants", points: points, plantType: plantType, planted: false });
        newSeedingJob.points = pointsID.toString();
    }
    const result = await client.db("farmbot").collection("seedingJobs").insertOne(newSeedingJob);
    console.log(`New seeding job created with the following id: ${result.insertedId}`);
    return result.insertedId;
}

async function getAllSeedingJobs(client) {
    const cursor = await client.db("farmbot").collection("seedingJobs").find();
    const results = await cursor.toArray();

    if (results.length > 0) {
        console.log(`Found seeding job(s):`);
        results.forEach((result, i) => {

            // Check if there is an array of points
            if (Array.isArray(result.points)) {
                console.log(`${i + 1}. name: ${result.name}`);
                console.log(`   _id: ${result._id}`);
                console.log('content: ', result);
            } else {
                // Replace point ID by array of points
                getPlantGroup(client, result.points)
                    .then((plantGroup) => {
                        result.points = plantGroup.points;

                        console.log(`${i + 1}. name: ${result.name}`);
                        console.log(`   _id: ${result._id}`);
                        console.log('content: ', result);
                    })
            }
        });
        return results;
    } else {
        console.log(`No seeding jobs found`);
        return [];
    }
}

async function getSeedingJob(client, id) {
    const result = await client.db("farmbot").collection("seedingJobs").findOne({ _id: mongodb.ObjectId(id.toString()) });

    if (result) {
        console.log('Found seeding job: ', result._id);

        /*
        // Check if there is an array of points
        if (!Array.isArray(result.points)) {
            // Replace point ID by array of points
            result.points = await getPlantGroup(client, result.points);

            console.log('Seeding job details: ', result);
        }
         */
        return result;
    } else {
        console.log(`No seeding job found`);
        return null;
    }
}

async function removeSeedingJob(client, id) {
    const result = await client.db("farmbot").collection("seedingJobs").findOne({ _id: mongodb.ObjectId(id.toString()) });
    if (result) {
        console.log(`Found a seeding job with the id: ${id}`);
        res = await client.db("farmbot").collection("seedingJobs").deleteOne(result);
        console.log(res);
    } else {
        console.log(`No Seeding Job found with the id: ${id}`);
    }
}

async function removeAllSeedingJobs(client) {
    const result = await client.db("farmbot").collection("seedingJobs").deleteMany({});

    console.log(`${result.deletedCount} seeding jobs deleted from farmbot database`);
}

module.exports = { addSeedingJob, getSeedingJob, getAllSeedingJobs, removeSeedingJob, removeAllSeedingJobs };

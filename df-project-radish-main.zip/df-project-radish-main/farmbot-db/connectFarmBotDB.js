const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;

const uri = 'mongodb://localhost/farmbot';
const client = new MongoClient(uri);

async function connect() {
    console.log(`Trying to connect to ${uri}`)

    try {
        await client.connect();

        console.log('Connection successful.');
        return client;

    } catch (e) {
        console.log('Failed to connect.', e.message);
    }
}

module.exports = connect;